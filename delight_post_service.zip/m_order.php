<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Money Form</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .form-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 30px;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h5 {
            text-align: center;
            margin-bottom: 25px;
            color: #343a40;
            font-size: 22px;
            font-weight: bold;
        }

        h4 {
            font-size: 18px;
            font-weight: bold;
            color: #007bff;
            margin-top: 20px;
            margin-bottom: 15px;
            text-align: center;
        }

        .form-control {
            border-radius: 5px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            border-radius: 5px;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .form-label {
            font-weight: bold;
            color: #343a40;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #aaa;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
<?php include 'loader.php'; ?>

    <?php include 'nav.php'; ?>

    <div class="form-container">
        <h5>Send Money Form</h5>
        <form action="msend.php" method="POST">

            <h4>Sender Details</h4>
            <div class="mb-3">
                <label for="sender_name" class="form-label">Name</label>
                <input type="text" class="form-control" id="sender_name" name="sender_name" required>
            </div>
            <div class="mb-3">
                <label for="sender_email" class="form-label">Email</label>
                <input type="email" class="form-control" id="sender_email" name="sender_email" required>
            </div>
            <div class="mb-3">
                <label for="sender_mobile" class="form-label">Mobile Number</label>
                <input type="text" class="form-control" id="sender_mobile" name="sender_mobile" placeholder="Enter your mobile number" required>
            </div>
            <div class="mb-3">
                <label for="sender_address" class="form-label">Address</label>
                <textarea class="form-control" id="sender_address" name="sender_address" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="sender_location" class="form-label">Location</label>
                <select class="form-select" id="sender_location" name="sender_location" required>
                    <option value="chikhli">Chikhli</option>
                    <option value="rankuva">Rankuva</option>
                </select>
            </div>

            <h4>Receiver Details</h4>
            <div class="mb-3">
                <label for="receiver_name" class="form-label">Name</label>
                <input type="text" class="form-control" id="receiver_name" name="receiver_name" required>
            </div>
            <div class="mb-3">
                <label for="receiver_email" class="form-label">Email</label>
                <input type="email" class="form-control" id="receiver_email" name="receiver_email" required>
            </div>
            <div class="mb-3">
                <label for="receiver_mobile" class="form-label">Mobile Number</label>
                <input type="text" class="form-control" id="receiver_mobile" name="receiver_mobile" placeholder="Enter receiver's mobile number" required>
            </div>
            <div class="mb-3">
                <label for="receiver_address" class="form-label">Address</label>
                <textarea class="form-control" id="receiver_address" name="receiver_address" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="receiver_location" class="form-label">Location</label>
                <select class="form-select" id="receiver_location" name="receiver_location" required>
                    <option value="chikhli">Chikhli</option>
                    <option value="rankuva">Rankuva</option>
                </select>
            </div>

            <h4>Amount Details</h4>
            <div class="mb-3">
                <label for="amount" class="form-label">Amount (INR)</label>
                <input type="number" step="0.01" class="form-control" id="amount" name="amount" required>
            </div>

            <button type="submit" name="send" class="btn btn-primary w-100">
                Send Money<i class="fas fa-arrow-right"></i>
            </button>
        </form>
    </div>

    <?php include 'footer.php'; ?>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>