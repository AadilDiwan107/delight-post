<?php
// Include the database connection file
require_once 'db.php';

// Fetch all routes from the database
$sql = "SELECT sender_location, receiver_location, price FROM routes";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();
$routes = $result->fetch_all(MYSQLI_ASSOC);

// Convert routes into an associative array for easy lookup
$route_prices = [];
foreach ($routes as $route) {
    $route_prices[$route['sender_location']][$route['receiver_location']] = $route['price'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parcel Order Form</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .form-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 30px;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        h5 {
            text-align: center;
            margin-bottom: 25px;
            color: #343a40;
            font-size: 22px;
            font-weight: bold;
        }
        h4 {
            font-size: 18px;
            font-weight: bold;
            color: #007bff;
            margin-top: 20px;
            margin-bottom: 15px;
            text-align: center;
        }
        .form-control {
            border-radius: 5px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            border-radius: 5px;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .form-label {
            font-weight: bold;
            color: #343a40;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #aaa;
        }
        .footer a {
            color: #007bff;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Style for the price text box */
        .price-textbox {
            text-align: center;
            font-weight: bold;
            color: green;
            margin-top: 15px;
        }
    </style>
</head>
<body>
<?php include 'loader.php'; ?>
    <?php include 'nav.php'; ?>
    <div class="form-container">
        <h5>Parcel Booking Form</h5>
        <form action="psend.php" method="POST" id="parcelForm">
            <h4>Sender Details</h4>
            <div class="mb-3">
                <label for="sender_name" class="form-label">Name</label>
                <input type="text" class="form-control" id="sender_name" name="sender_name" required>
            </div>
            <div class="mb-3">
                <label for="sender_email" class="form-label">Email</label>
                <input type="email" class="form-control" id="sender_email" name="sender_email" required>
            </div>
            <div class="mb-3">
                <label for="sender_mobile" class="form-label">Mobile Number</label>
                <input type="text" class="form-control" id="sender_mobile" name="sender_mobile" required>
            </div>
            <div class="mb-3">
                <label for="sender_address" class="form-label">Address</label>
                <textarea class="form-control" id="sender_address" name="sender_address" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="sender_location" class="form-label">Location</label>
                <select class="form-select" id="sender_location" name="sender_location" required>
                    <option value="">Select Sender Location</option>
                    <?php
                    // Populate sender locations from the database
                    $unique_sender_locations = array_keys($route_prices);
                    foreach ($unique_sender_locations as $location) {
                        echo "<option value='$location'>$location</option>";
                    }
                    ?>
                </select>
            </div>
            <h4>Receiver Details</h4>
            <div class="mb-3">
                <label for="receiver_name" class="form-label">Name</label>
                <input type="text" class="form-control" id="receiver_name" name="receiver_name" required>
            </div>
            <div class="mb-3">
                <label for="receiver_email" class="form-label">Email</label>
                <input type="email" class="form-control" id="receiver_email" name="receiver_email" required>
            </div>
            <div class="mb-3">
                <label for="receiver_mobile" class="form-label">Mobile Number</label>
                <input type="text" class="form-control" id="receiver_mobile" name="receiver_mobile" required>
            </div>
            <div class="mb-3">
                <label for="receiver_address" class="form-label">Address</label>
                <textarea class="form-control" id="receiver_address" name="receiver_address" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="receiver_location" class="form-label">Location</label>
                <select class="form-select" id="receiver_location" name="receiver_location" required>
                    <option value="">Select Receiver Location</option>
                    
                </select>
            </div>
            <h4>Parcel Details</h4>
            <div class="mb-3">
                <label for="parcel_weight" class="form-label">Weight (kg)</label>
                <input type="number" step="0.01" class="form-control" id="parcel_weight" name="parcel_weight" required>
                <div class="error-message" id="weightError">
                    The weight must be between 1 and 2 kg.
                </div>
            </div>
            <div class="mb-3">
                <label for="parcel_type" class="form-label">Type</label>
                <select class="form-select" id="parcel_type" name="parcel_type" required>
                    <option value="normal">Normal</option>
                    <option value="sensitive">Sensitive</option>
                </select>
            </div>
            <!-- Price Text Box -->
            <div class="mb-3">
                <label for="calculatedPrice" class="form-label">Price</label>
                <input type="text" class="form-control price-textbox" id="calculatedPrice" name="price" readonly>
            </div>
            <button type="submit" name="send" class="btn btn-primary w-100">
                Book Parcel<i class="fas fa-arrow-right"></i>
            </button>
        </form>
    </div>
    <?php include 'footer.php'; ?>
    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Get references to elements
            const senderLocation = document.getElementById('sender_location');
            const receiverLocation = document.getElementById('receiver_location');
            const calculatedPriceInput = document.getElementById('calculatedPrice');

            // PHP data passed to JavaScript
            const routePrices = <?php echo json_encode($route_prices); ?>;

            // Populate receiver locations dynamically based on sender location
            senderLocation.addEventListener('change', function () {
                const selectedSender = senderLocation.value;
                receiverLocation.innerHTML = '<option value="">Select Receiver Location</option>';
                if (selectedSender && routePrices[selectedSender]) {
                    Object.keys(routePrices[selectedSender]).forEach(location => {
                        const option = document.createElement('option');
                        option.value = location;
                        option.textContent = location;
                        receiverLocation.appendChild(option);
                    });
                }
                // Reset price text box
                calculatedPriceInput.value = '';
            });

            // Calculate and display price when receiver location is selected
            receiverLocation.addEventListener('change', function () {
                const selectedSender = senderLocation.value;
                const selectedReceiver = receiverLocation.value;
                if (selectedSender && selectedReceiver && routePrices[selectedSender][selectedReceiver]) {
                    const price = routePrices[selectedSender][selectedReceiver];
                    calculatedPriceInput.value = `₹${price}`;
                } else {
                    calculatedPriceInput.value = '';
                }
            });

            // Validate the weight when the form is submitted
            document.getElementById('parcelForm').addEventListener('submit', function (event) {
                const weightInput = document.getElementById('parcel_weight');
                const weight = parseFloat(weightInput.value);
                // Check if the weight is between 1 and 2 kg
                if (isNaN(weight) || weight < 1 || weight > 2) {
                    event.preventDefault(); // Prevent form submission
                    document.getElementById('weightError').style.display = 'block'; // Show the error message
                } else {
                    document.getElementById('weightError').style.display = 'none'; // Hide the error message if valid
                }
            });
        });
    </script>
</body>
</html>