<?php
session_start(); // Start the session (optional if not using login)

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";

// Establish connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$tracking_id = '';
$parcel_details = null;
$error_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the tracking ID from the form
    $tracking_id = trim($_POST['tracking_id']);

    // Validate the tracking ID
    if (empty($tracking_id)) {
        $error_message = "Please enter a valid Tracking ID.";
    } else {
        // Query the database for the parcel details
        $sql = "SELECT * FROM parcels WHERE track_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $tracking_id); // Bind the tracking ID parameter
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Fetch the parcel details
            $parcel_details = $result->fetch_assoc();
        } else {
            $error_message = "No parcel found with the provided Tracking ID.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Parcel</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 1200px; /* Adjusted for larger displays */
            margin-top: 50px;
        }

        h3 {
            text-align: center;
            color: #343a40;
            margin-bottom: 30px;
        }

        .input-group {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .form-control {
            border: none;
            box-shadow: none;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .card {
            margin-top: 20px;
            border: none;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .card img {
            width: 100%;
            height: auto;
            border-radius: 8px 8px 0 0;
        }

        .card-header {
            background-color: #007bff;
            color: white;
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            border-radius: 8px 8px 0 0;
        }

        .card-body p {
            margin-bottom: 10px;
            font-size: 14px;
            color: #495057;
        }

        .card-body p strong {
            color: #343a40;
            font-weight: bold;
        }

        .alert {
            margin-top: 20px;
            border-radius: 8px;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 12px;
            color: #aaa;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
<?php include 'loader.php'; ?>

    <?php include 'nav.php'; ?>

    <div class="container">
        

        <!-- Cards Row -->
        <div class="row mt-4">
            <!-- Card 1: Parcel Order Tracking -->
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="card">
                    <img src="https://images.pexels.com/photos/6667691/pexels-photo-6667691.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Parcel Tracking" class="card-img-top">
                    <div class="card-header bg-primary text-white">
                        <i class="fas fa-truck"></i> Parcel Order Tracking
                    </div>
                    <div class="card-body">
                        <p>Track your parcel orders and get real-time updates on their delivery status.</p>
                        <a href="track.php" class="btn btn-primary w-100">Track Parcel <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <!-- Card 2: Money Order Tracking -->
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="card">
                    <img src="https://images.pexels.com/photos/210990/pexels-photo-210990.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Money Tracking" class="card-img-top">
                    <div class="card-header bg-primary text-white">
                        <i class="fas fa-money-bill-wave"></i> Money Order Tracking
                    </div>
                    <div class="card-body">
                        <p>Track your money orders and monitor their processing status.</p>
                        <a href="m_track.php" class="btn btn-primary w-100">Track Money Order <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <!-- Card 3: Article Order Tracking -->
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="card">
                    <img src="article.jpg" alt="Article Tracking" class="card-img-top">
                    <div class="card-header bg-primary text-white">
                        <i class="fas fa-newspaper"></i> Article Order Tracking
                    </div>
                    <div class="card-body">
                        <p>Track your article orders and stay updated on their publication or delivery status.</p>
                        <a href="track_article.php" class="btn btn-primary w-100">Track Article <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <?php include 'footer.php'; ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>