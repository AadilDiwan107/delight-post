<?php
session_start();

// Redirect to login page if admin is not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Update Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_rider'])) {
    $rider_id = $_POST['rider_id'];
    $rider_name = trim($_POST['rider_name']);
    $rider_email = trim($_POST['rider_email']);
    $rider_phone = trim($_POST['rider_phone']);
    $license_number = trim($_POST['license_number']);

    // Validate inputs
    if (empty($rider_name) || empty($rider_email) || empty($rider_phone) || empty($license_number)) {
        $error_message = "All fields are required.";
    } elseif (!filter_var($rider_email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
    } else {
        // Update the rider's details in the database
        $update_sql = "UPDATE riders SET rider_name = ?, rider_email = ?, rider_phone = ?, license_number = ? WHERE id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("ssssi", $rider_name, $rider_email, $rider_phone, $license_number, $rider_id);

        if ($stmt->execute()) {
            $success_message = "Rider updated successfully.";
        } else {
            $error_message = "Error updating rider. Please try again.";
        }
    }
}

// Handle Delete Action
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $rider_id = $_GET['id'];

    // Delete the rider from the database
    $delete_sql = "DELETE FROM riders WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $rider_id);

    if ($stmt->execute()) {
        $success_message = "Rider deleted successfully.";
    } else {
        $error_message = "Error deleting rider. Please try again.";
    }
}

// Fetch all riders
$rider_sql = "SELECT * FROM riders";
$rider_stmt = $conn->prepare($rider_sql);
$rider_stmt->execute();
$rider_result = $rider_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Riders</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 1200px;
            margin: 50px auto;
        }

        h3 {
            text-align: center;
            color: #343a40;
            margin-bottom: 30px;
        }

        .table {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .table thead {
            background-color: #007bff;
            color: white;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .btn-custom {
            background-color: #007bff;
            border: none;
            transition: background-color 0.3s ease-in-out;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #aaa;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .alert-info {
            text-align: center;
            font-size: 1rem;
            color: #0c5460;
            background-color: #d1ecf1;
            border-color: #bee5eb;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 500px;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            z-index: 9999;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 9998;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <!-- Brand Logo -->
            <a class="navbar-brand" href="admin.php">
                <i class="fas fa-tachometer-alt"></i> Admin Panel
            </a>

            <!-- Toggler Button for Mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar Links -->
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">
                            <i class="fas fa-home"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="rdata.php">
                            <i class="fas fa-motorcycle"></i> Manage Riders
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="udata.php">
                            <i class="fas fa-users"></i> Manage Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="aparcels.php">
                            <i class="fas fa-box-open"></i> View Parcels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <h3><i class="fas fa-motorcycle"></i> All Riders</h3>

        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>License Number</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($rider_result->num_rows > 0): ?>
                    <?php while ($rider = $rider_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($rider['id']); ?></td>
                            <td><?php echo htmlspecialchars($rider['rider_name']); ?></td>
                            <td><?php echo htmlspecialchars($rider['rider_email']); ?></td>
                            <td><?php echo htmlspecialchars($rider['rider_phone']); ?></td>
                            <td><?php echo htmlspecialchars($rider['license_number']); ?></td>
                            <td><?php echo htmlspecialchars($rider['status']); ?></td>
                            <td>
                                <!-- Edit Button -->
                                <button class="btn btn-warning btn-sm me-2 edit-btn"
                                    data-id="<?php echo htmlspecialchars($rider['id']); ?>"
                                    data-name="<?php echo htmlspecialchars($rider['rider_name']); ?>"
                                    data-email="<?php echo htmlspecialchars($rider['rider_email']); ?>"
                                    data-phone="<?php echo htmlspecialchars($rider['rider_phone']); ?>"
                                    data-license="<?php echo htmlspecialchars($rider['license_number']); ?>">
                                    <i class="fas fa-edit"></i> Edit
                                </button>

                                <!-- Delete Button -->
                                <a href="?action=delete&id=<?php echo htmlspecialchars($rider['id']); ?>"
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Are you sure you want to delete this rider?');">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">No riders found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Edit Rider Modal -->
    <div class="modal" id="editModal">
        <div class="modal-header">
            <h4 class="modal-title"><i class="fas fa-edit"></i> Edit Rider Details</h4>
        </div>
        <form method="POST" action="">
            <div class="modal-body">
                <input type="hidden" id="rider_id" name="rider_id">
                <div class="mb-3">
                    <label for="rider_name" class="form-label">Name</label>
                    <input type="text" class="form-control" id="rider_name" name="rider_name" required>
                </div>
                <div class="mb-3">
                    <label for="rider_email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="rider_email" name="rider_email" required>
                </div>
                <div class="mb-3">
                    <label for="rider_phone" class="form-label">Phone</label>
                    <input type="text" class="form-control" id="rider_phone" name="rider_phone" required>
                </div>
                <div class="mb-3">
                    <label for="license_number" class="form-label">License Number</label>
                    <input type="text" class="form-control" id="license_number" name="license_number" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="update_rider" class="btn btn-primary">Update</button>
                <button type="button" class="btn btn-secondary close-modal">Cancel</button>
            </div>
        </form>
    </div>

    <!-- Overlay for Modal -->
    <div class="overlay" id="overlay"></div>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const modal = document.getElementById("editModal");
            const overlay = document.getElementById("overlay");

            // Open the modal when the edit button is clicked
            document.querySelectorAll(".edit-btn").forEach(button => {
                button.addEventListener("click", function () {
                    const riderId = this.getAttribute("data-id");
                    const riderName = this.getAttribute("data-name");
                    const riderEmail = this.getAttribute("data-email");
                    const riderPhone = this.getAttribute("data-phone");
                    const licenseNumber = this.getAttribute("data-license");

                    // Populate the modal fields
                    document.getElementById("rider_id").value = riderId;
                    document.getElementById("rider_name").value = riderName;
                    document.getElementById("rider_email").value = riderEmail;
                    document.getElementById("rider_phone").value = riderPhone;
                    document.getElementById("license_number").value = licenseNumber;

                    // Show the modal and overlay
                    modal.style.display = "block";
                    overlay.style.display = "block";
                });
            });

            // Close the modal when the cancel button or overlay is clicked
            document.querySelectorAll(".close-modal, #overlay").forEach(element => {
                element.addEventListener("click", function () {
                    modal.style.display = "none";
                    overlay.style.display = "none";
                });
            });
        });
    </script>
</body>

</html>