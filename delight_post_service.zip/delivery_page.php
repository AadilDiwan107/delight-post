<?php
// Include the database connection file
require_once 'db.php';

// Check if the tracking ID is provided in the query string
if (!isset($_GET['track_id']) || empty(trim($_GET['track_id']))) {
    echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                const modal = document.getElementById('customModal');
                modal.style.display = 'block';
                document.getElementById('modalMessage').innerText = 'Invalid request. Please provide a valid Tracking ID.';
                document.getElementById('modalClose').onclick = function() {
                    window.location.href = 'rider_dashboard.php';
                };
            });
          </script>";
    exit;
}

$track_id = trim($_GET['track_id']);

// Fetch parcel details from the database
$sql = "SELECT * FROM parcels WHERE track_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $track_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if the parcel exists
if ($result->num_rows === 0) {
    echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                const modal = document.getElementById('customModal');
                modal.style.display = 'block';
                document.getElementById('modalMessage').innerText = 'Invalid request. Parcel not found.';
                document.getElementById('modalClose').onclick = function() {
                    window.location.href = 'rider_dashboard.php';
                };
            });
          </script>";
    exit;
}

$parcel = $result->fetch_assoc();

// Check if the parcel status is already "Delivered"
if ($parcel['status'] === 'Delivered') {
    echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                const modal = document.getElementById('customModal');
                modal.style.display = 'block';
                document.getElementById('modalMessage').innerText = 'This parcel has already been delivered. Status cannot be updated.';
                document.getElementById('modalClose').onclick = function() {
                    window.location.href = 'rider_dashboard.php';
                };
            });
          </script>";
    exit;
}

// Handle status update if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = trim($_POST['status']);

    // Update the parcel status in the database
    $update_sql = "UPDATE parcels SET status = ? WHERE track_id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ss", $new_status, $track_id);

    if ($stmt->execute()) {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    const modal = document.getElementById('customModal');
                    modal.style.display = 'block';
                    document.getElementById('modalMessage').innerText = 'Status updated successfully!';
                    document.getElementById('modalClose').onclick = function() {
                        window.location.href = 'delivery_page.php?track_id=$track_id';
                    };
                });
              </script>";
    } else {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    const modal = document.getElementById('customModal');
                    modal.style.display = 'block';
                    document.getElementById('modalMessage').innerText = 'Error updating status. Please try again.';
                    document.getElementById('modalClose').onclick = function() {
                        window.location.reload();
                    };
                });
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Page</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
        }

        h3 {
            text-align: center;
            color: #343a40;
            margin-bottom: 20px;
        }

        .card {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #aaa;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        /* Custom Modal Styling */
        #customModal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
        }

        #customModalContent {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            border-radius: 10px;
            width: 400px;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        #modalMessage {
            font-size: 18px;
            margin-bottom: 20px;
            color: #343a40;
        }

        #modalClose {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }

        #modalClose:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="container">
        <h3><i class="fas fa-box"></i> Delivery Details</h3>

        <div class="card">
            <div class="card-header bg-primary text-white">
                Tracking ID: <?php echo htmlspecialchars($parcel['track_id']); ?>
            </div>
            <div class="card-body">
                <p><strong>Sender Name:</strong> <?php echo htmlspecialchars($parcel['sender_name']); ?></p>
                <p><strong>Sender Email:</strong> <?php echo htmlspecialchars($parcel['sender_email']); ?></p>
                <p><strong>Sender Phone:</strong> <?php echo htmlspecialchars($parcel['sender_mobile']); ?></p>
                <p><strong>Sender Address:</strong> <?php echo htmlspecialchars($parcel['sender_address']); ?></p>
                <p><strong>Receiver Name:</strong> <?php echo htmlspecialchars($parcel['receiver_name']); ?></p>
                <p><strong>Receiver Email:</strong> <?php echo htmlspecialchars($parcel['receiver_email']); ?></p>
                <p><strong>Receiver Phone:</strong> <?php echo htmlspecialchars($parcel['receiver_mobile']); ?></p>
                <p><strong>Receiver Address:</strong> <?php echo htmlspecialchars($parcel['receiver_address']); ?></p>
                <p><strong>Parcel Weight:</strong> <?php echo htmlspecialchars($parcel['parcel_weight']); ?> kg</p>
                <p><strong>Parcel Type:</strong> <?php echo htmlspecialchars($parcel['parcel_type']); ?></p>
                <p><strong>Status:</strong>
                    <?php
                    $status = $parcel['status'] ?? 'Pending';
                    $status_class = match ($status) {
                        'Pending' => 'text-warning',
                        'Shipped' => 'text-info',
                        'Delivered' => 'text-success',
                        default => 'text-secondary'
                    };
                    echo "<span class='$status_class'><i class='fas fa-circle'></i> $status</span>";
                    ?>
                </p>

                <!-- Status Update Form -->
                <?php if ($parcel['status'] !== 'Delivered'): ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="status" class="form-label"><strong>Update Status</strong></label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="Pending" <?php echo ($parcel['status'] === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                <option value="Shipped" <?php echo ($parcel['status'] === 'Shipped') ? 'selected' : ''; ?>>Shipped</option>
                                <option value="Delivered" <?php echo ($parcel['status'] === 'Delivered') ? 'selected' : ''; ?>>Delivered</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Update Status</button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-info" role="alert">
                        This parcel has already been delivered. Status cannot be updated.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="footer">
            <p>&copy; 2023 Delight Private Limited. All rights reserved. |
                <a href="#">Privacy Policy</a> |
                <a href="#">Terms of Service</a>
            </p>
        </div>
    </div>

    <!-- Custom Modal -->
    <div id="customModal">
        <div id="customModalContent">
            <p id="modalMessage"></p>
            <button id="modalClose">Ok</button>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>