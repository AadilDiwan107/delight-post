<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start(); // Start the session to access user data

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";

// Database connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send'])) {

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        echo "
        <script>
            alert('You must be logged in to book a parcel.');
            document.location.href='login.php'; // Redirect to login page
        </script>";
        exit();
    }

    // Retrieve the logged-in user's ID
    $user_id = $_SESSION['user_id'];

    // Collect and sanitize form data
    $sender_name = trim($_POST['sender_name']);
    $sender_email = trim($_POST['sender_email']);
    $sender_mobile = trim($_POST['sender_mobile']);
    $sender_address = trim($_POST['sender_address']);
    $sender_location = trim($_POST['sender_location']);

    $receiver_name = trim($_POST['receiver_name']);
    $receiver_email = trim($_POST['receiver_email']);
    $receiver_mobile = trim($_POST['receiver_mobile']);
    $receiver_address = trim($_POST['receiver_address']);
    $receiver_location = trim($_POST['receiver_location']);

    $parcel_weight = floatval($_POST['parcel_weight']);
    $parcel_type = trim($_POST['parcel_type']);
    $price = floatval($_POST['price']); // Price from the form

    // Generate a three-digit random number for tracking
    $tracking_id = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);

    // Insert parcel details into the database with the tracking ID, price, and user ID
    $insert_sql = "INSERT INTO parcels (
        sender_name, sender_email, sender_mobile, sender_address, sender_location,
        receiver_name, receiver_email, receiver_mobile, receiver_address, receiver_location,
        parcel_weight, parcel_type, price, status, created_at, track_id, user_id
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW(), ?, ?)";

    $stmt = $conn->prepare($insert_sql);

    // Bind parameters
    $stmt->bind_param(
        "sssssssssdssssi", // Updated type definition string to match the number of variables
        $sender_name,
        $sender_email,
        $sender_mobile,
        $sender_address,
        $sender_location,
        $receiver_name,
        $receiver_email,
        $receiver_mobile,
        $receiver_address,
        $receiver_location,
        $parcel_weight,
        $parcel_type,
        $price,
        $tracking_id,
        $user_id
    );
    if ($stmt->execute()) {

        // Send confirmation email using PHPMailer
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'AadilDiwan107@gmail.com'; // Replace with your email
            $mail->Password = 'ctfoqugwfjkxkbzq'; // Replace with your app password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;

            $mail->setFrom('AadilDiwan107@gmail.com', 'Delight Private Limited');
            $mail->addAddress($sender_email); // Send to sender's email
            $mail->addAddress($receiver_email); // Send to receiver's email
            $mail->isHTML(true);
            $mail->Subject = 'Parcel Booking Confirmation';

            // Constructing a well-structured, professional email body with CSS
            $mail->Body = "
            <html>
            <head>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f4f7fc;
                        color: #333;
                        padding: 20px;
                    }
                    .email-container {
                        background-color: #ffffff;
                        border-radius: 8px;
                        padding: 30px;
                        border: 1px solid #ddd;
                        max-width: 600px;
                        margin: 0 auto;
                    }
                    .header {
                        background-color: #007bff;
                        color: white;
                        padding: 20px;
                        text-align: center;
                        border-radius: 8px 8px 0 0;
                    }
                    .content {
                        margin-top: 20px;
                    }
                    .footer {
                        text-align: center;
                        margin-top: 30px;
                        font-size: 12px;
                        color: #aaa;
                    }
                    .button {
                        background-color: #007bff;
                        color: white;
                        padding: 12px 30px;
                        border-radius: 5px;
                        text-decoration: none;
                    }
                    .button:hover {
                        background-color: #0056b3;
                    }
                </style>
            </head>
            <body>
                <div class='email-container'>
                    <div class='header'>
                        <h2>Parcel Booking Confirmation</h2>
                    </div>
                    <div class='content'>
                        <p>Hello <strong>$sender_name</strong> and <strong>$receiver_name</strong>,</p>
                        <p>Your parcel has been successfully booked with the following details:</p>
                        <ul>
                            <li><strong>Tracking ID:</strong> $tracking_id</li>
                            <li><strong>Sender Name:</strong> $sender_name</li>
                            <li><strong>Receiver Name:</strong> $receiver_name</li>
                            <li><strong>Parcel Weight:</strong> $parcel_weight kg</li>
                            <li><strong>Parcel Type:</strong> $parcel_type</li>
                            <li><strong>Price:</strong> ₹$price</li> <!-- Include price in the email -->
                        </ul>
                         <p>Thank you for booking with us!</p>
                         <p>If you have any questions or need further assistance, please don't hesitate to contact us at <a href='mailto:support@Delight.com'>support@Delight.com</a>.</p>
                        <p>Thank you for your trust and support!</p>
                        <p>Best regards,<br><strong>Delight Private Limited</strong></p>
                    </div>
                    <div class='footer'>
                        <p>For support, contact us at <a href='mailto:support@Delight.com'>support@Delight.com</a></p>
                    </div>
                </div>
            </body>
            </html>
            ";

            // Send the email
            $mail->send();

            // Redirect to parcels.php after successful booking
            echo "
            <script>
                alert('Parcel booked successfully! Redirecting to parcels page...');
                document.location.href='parcels.php';
            </script>";
        } catch (Exception $e) {
            echo "
            <script>
                alert('Error sending email: {$mail->ErrorInfo}');
                document.location.href='index.php';
            </script>
            ";
        }
    } else {
        echo "
        <script>
            alert('Error inserting data: {$conn->error}');
            document.location.href = 'index.php';
        </script>
        ";
    }
}
?>