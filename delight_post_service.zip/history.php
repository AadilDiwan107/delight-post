<?php
// Database connection
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'parcel_service';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = isset($_GET['email']) ? $_GET['email'] : '';

if ($email) {
    $sql = "SELECT * FROM parcels WHERE sender_email = '$email'";
    $result = $conn->query($sql);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h2 class="text-center">Order History</h2>
        <form method="GET" action="">
            <div class="mb-3">
                <label for="email" class="form-label">Enter Your Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($email) ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">View Orders</button>
        </form>

        <?php if ($email && $result->num_rows > 0): ?>
            <table class="table mt-4">
                <thead>
                    <tr>
                        <th>Track ID</th>
                        <th>Sender Name</th>
                        <th>Receiver Name</th>
                        <th>Parcel Weight</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['track_id']) ?></td>
                            <td><?= htmlspecialchars($row['sender_name']) ?></td>
                            <td><?= htmlspecialchars($row['receiver_name']) ?></td>
                            <td><?= htmlspecialchars($row['parcel_weight']) ?> kg</td>
                            <td><?= htmlspecialchars($row['status']) ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php elseif ($email): ?>
            <p class="mt-4 text-center">No orders found for this email.</p>
        <?php endif; ?>
    </div>
</body>

</html>