<?php
session_start();
// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Fetch user details
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    // User not found, redirect to login
    header("Location: login.php");
    exit();
}
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Image Slider Styles */
        .slider {
            position: relative;
            width: 100vw;
            /* Full viewport width */
            height: 45vh;
            /* Full viewport height */
            overflow: hidden;
        }

        .slider img {
            width: 100%;
            /* Stretch to full width */
            height: 100%;
            /* Stretch to full height */
            object-fit: cover;
            /* Maintain aspect ratio and cover the container */
            position: absolute;
            top: 0;
            left: 0;
            display: none;
            /* Hide all images by default */
        }

        .slider img.active {
            display: block;
            /* Show only the active image */
        }

        /* Custom Welcome Message Styles */
        .welcome-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
        }

        .welcome-card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            background: linear-gradient(145deg, #6a11cb, #2575fc);
            color: white;
            font-size: 1.5rem;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-radius: 15px 15px 0 0;
        }

        .card-body {
            font-size: 1.2rem;
            line-height: 1.6;
            color: #343a40;
        }

        .btn-logout {
            background-color: #dc3545;
            border: none;
            font-size: 1rem;
            font-weight: bold;
            padding: 10px;
            border-radius: 10px;
            transition: background-color 0.3s ease-in-out;
        }

        .btn-logout:hover {
            background-color: #b02a37;
        }

        /* Post Services Section Styles */
        .services-section {
            margin-top: 30px;
        }

        .service-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
        }

        .service-card:hover {
            transform: translateY(-5px);
        }

        .service-icon {
            font-size: 2rem;
            color: #007bff;
        }
    </style>
</head>

<body>
    <?php include 'loader.php'; ?>
    <?php include 'nav.php'; ?>

    <!-- Image Slider -->
    <div class="slider">
        <img src="https://images.pexels.com/photos/947384/pexels-photo-947384.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Image 1" class="active">
        <img src="https://images.pexels.com/photos/6869055/pexels-photo-6869055.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Image 2">
        <img src="https://images.pexels.com/photos/10149610/pexels-photo-10149610.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Image 3">
    </div>

    <!-- Dashboard Content -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card welcome-card">
                    <div class="card-header text-center">
                        Welcome, <?php echo htmlspecialchars($user['name']); ?>!
                    </div>
                    <div class="card-body">
                        <p><strong>Your Email ID is:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                        <a href="logout.php" class="btn btn-logout w-100">Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Post Services Section -->
        <div class="services-section mt-5">
            <h3 class="text-center mb-4">Our Parcel Services</h3>
            <div class="row">
                <!-- Service 1: Book Parcel -->
                <div class="col-md-4">
                    <div class="card service-card text-center">
                        <div class="card-body">
                            <i class="fas fa-box-open service-icon"></i>
                            <h5 class="card-title mt-3">Book a Parcel</h5>
                            <p class="card-text">Easily book your parcels online with our simple form. Provide sender and receiver details, and let us handle the rest.</p>
                            <a href="parcel_order.php" class="btn btn-primary">Book Now</a>
                        </div>
                    </div>
                </div>

                <!-- Service 2: Track Parcel -->
                <div class="col-md-4">
                    <div class="card service-card text-center">
                        <div class="card-body">
                            <i class="fas fa-map-marker-alt service-icon"></i>
                            <h5 class="card-title mt-3">Track Your Parcel</h5>
                            <p class="card-text">Track your parcel in real-time using the tracking ID. Stay updated on the status of your delivery.</p>
                            <a href="tracking.php" class="btn btn-primary">Track Now</a>
                        </div>
                    </div>
                </div>

                <!-- Service 3: Cancel Parcel -->
                <div class="col-md-4">
    <div class="card service-card text-center">
        <div class="card-body">
            <i class="fas fa-list-alt service-icon"></i> <!-- Updated icon -->
            <h5 class="card-title mt-3">View Your Orders</h5> <!-- Updated title -->
            <p class="card-text">View all your booked parcels, track their status, and manage them directly from your dashboard.</p> <!-- Updated description -->
            <a href="parcels.php" class="btn btn-primary">View Orders</a> <!-- Updated button text -->
        </div>
    </div>
</div>
            </div>
        </div>

        <!-- Additional Parcel Services Section -->
        <div class="services-section mt-5">
            <div class="row">
                <!-- Service 4: Parcel Insurance -->
                <div class="col-md-4">
    <div class="card service-card text-center">
        <div class="card-body">
            <i class="fas fa-user-circle service-icon"></i> <!-- Updated icon -->
            <h5 class="card-title mt-3">View Your Profile</h5> <!-- Updated title -->
            <p class="card-text">View and manage your personal information, including name, email, and contact details. Update your profile anytime from here.</p> <!-- Updated description -->
            <a href="profile.php" class="btn btn-primary">View Profile</a> <!-- Updated button text and link -->
        </div>
    </div>
</div>
                <!-- Service 5: Parcel Storage -->
                <div class="col-md-4">
    <div class="card service-card text-center">
        <div class="card-body">
            <i class="fas fa-money-check-alt service-icon"></i> <!-- Updated icon -->
            <h5 class="card-title mt-3">Money Order</h5> <!-- Updated title -->
            <p class="card-text">Send and receive money securely with our money order services. Fast, reliable, and hassle-free transactions for your convenience.</p> <!-- Updated description -->
            <a href="m_order.php" class="btn btn-primary">Send Money</a> <!-- Updated button text and link -->
        </div>
    </div>
</div>

                
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // JavaScript for Image Slider
    document.addEventListener("DOMContentLoaded", function() {
        const images = document.querySelectorAll(".slider img");
        let currentIndex = 0;

        function showNextImage() {
            // Hide the current image
            images[currentIndex].classList.remove("active");

            // Move to the next image
            currentIndex = (currentIndex + 1) % images.length;

            // Show the next image
            images[currentIndex].classList.add("active");
        }

        // Change image every 3 seconds
        setInterval(showNextImage, 3000);
    });
</script>

</html>
