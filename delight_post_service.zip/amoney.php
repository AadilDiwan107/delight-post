<?php
session_start();

// Redirect to login page if admin is not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: alogin.php");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$email = $amount = '';
$errors = [];
$success_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input data
    $email = trim($_POST['email']);
    $amount = trim($_POST['amount']);
    $action = $_POST['action']; // 'add' or 'withdraw'

    // Validate inputs
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email address is required.";
    }
    if (empty($amount) || !is_numeric($amount) || $amount <= 0) {
        $errors[] = "Please enter a valid positive amount.";
    }

    // If no validation errors, proceed to update the user's balance
    if (empty($errors)) {
        // Check if the user exists in the database
        $check_user_sql = "SELECT id, amount FROM users WHERE email = ?";
        $stmt = $conn->prepare($check_user_sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $user_id = $user['id'];
            $current_amount = $user['amount'];

            // Perform the action (add or withdraw)
            if ($action === 'add') {
                $new_amount = $current_amount + $amount;
                $action_message = "₹{$amount} added successfully to the user's account.";
                $transaction_type = 'add';
            } elseif ($action === 'withdraw') {
                if ($current_amount < $amount) {
                    $errors[] = "Insufficient balance to withdraw ₹{$amount}. Current balance: ₹{$current_amount}";
                } else {
                    $new_amount = $current_amount - $amount;
                    $action_message = "₹{$amount} withdrawn successfully from the user's account.";
                    $transaction_type = 'withdraw';
                }
            }

            // Update the user's amount if no errors
            if (empty($errors)) {
                $update_sql = "UPDATE users SET amount = ? WHERE id = ?";
                $stmt = $conn->prepare($update_sql);
                $stmt->bind_param("di", $new_amount, $user_id);

                if ($stmt->execute()) {
                    // Insert transaction into the transactions table
                    $insert_transaction_sql = "INSERT INTO transactions (user_id, amount, transaction_type) VALUES (?, ?, ?)";
                    $stmt = $conn->prepare($insert_transaction_sql);
                    $stmt->bind_param("ids", $user_id, $amount, $transaction_type);

                    if ($stmt->execute()) {
                        $success_message = $action_message . " Current balance: ₹{$new_amount}";
                    } else {
                        $errors[] = "Failed to log the transaction. Please try again.";
                    }
                } else {
                    $errors[] = "Failed to update the user's balance. Please try again.";
                }
            }
        } else {
            $errors[] = "No user found with the provided email address.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add/Withdraw Money</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
        }

        h3 {
            text-align: center;
            color: #343a40;
            margin-bottom: 30px;
        }

        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25);
        }

        .error-message {
            color: red;
            font-size: 0.9rem;
            margin-top: -10px;
            margin-bottom: 10px;
        }

        .success-message {
            color: green;
            font-size: 1rem;
            margin-bottom: 10px;
        }

        .btn-custom {
            background-color: #007bff;
            border: none;
            transition: background-color 0.3s ease-in-out;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }

        .btn-withdraw {
            background-color: #dc3545;
        }

        .btn-withdraw:hover {
            background-color: #b02a37;
        }
    </style>
</head>

<body>
    <?php include 'nav.php'; ?>
    <div class="container">
        <h3><i class="fas fa-money-bill-wave"></i> Add/Withdraw Money</h3>

        <!-- Display success or error messages -->
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success" role="alert">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger" role="alert">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Add/Withdraw Money Form -->
        <form action="amoney.php" method="POST">
            <div class="mb-3">
                <label for="email" class="form-label">User Email Address</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            <div class="mb-3">
                <label for="amount" class="form-label">Amount (₹)</label>
                <input type="number" step="0.01" class="form-control" id="amount" name="amount" value="<?php echo htmlspecialchars($amount); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Action</label>
                <select class="form-select" name="action" required>
                    <option value="add">Add Money</option>
                    <option value="withdraw">Withdraw Money</option>
                </select>
            </div>
            <button type="submit" class="btn btn-custom w-100">Submit</button>
        </form>
    </div>
    <?php include 'footer.php'; ?>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>