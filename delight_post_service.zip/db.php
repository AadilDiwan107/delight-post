<?php
// Database configuration
$host = 'localhost';     // Replace with your database host (e.g., localhost)
$username = 'root';      // Replace with your database username
$password = '';          // Replace with your database password
$database = 'delight'; // Replace with your database name

// Create a new MySQLi connection
$conn = new mysqli($host, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    // If the connection fails, terminate the script and display an error message
    die("Database connection failed: " . $conn->connect_error);
}

// Optional: Set the character set to UTF-8 for better compatibility
$conn->set_charset("utf8");

// Export the connection object so it can be used in other files
// You can now include this file wherever you need the database connection
