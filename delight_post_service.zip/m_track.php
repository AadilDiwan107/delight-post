<?php
session_start(); // Start session if needed

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error_message = '';
$order_details = null;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['track'])) {
    $tracking_id = trim($_POST['tracking_id']);

    if (empty($tracking_id)) {
        $error_message = "Please enter a valid Tracking ID.";
    } else {
        // Query the database for the money order details
        $sql = "SELECT * FROM money_orders WHERE track_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $tracking_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $order_details = $result->fetch_assoc();
        } else {
            $error_message = "No money order found with the provided Tracking ID.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Money Order</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .form-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 30px;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h5 {
            text-align: center;
            margin-bottom: 25px;
            color: #343a40;
            font-size: 22px;
            font-weight: bold;
        }

        .form-control {
            border-radius: 5px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            border-radius: 5px;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .error-message {
            color: red;
            font-size: 14px;
            text-align: center;
            margin-top: 10px;
        }

        .order-details {
            margin-top: 30px;
            padding: 20px;
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 10px;
        }

        .order-details p {
            margin: 10px 0;
            font-size: 16px;
        }

        .status-pending {
            color: orange;
            font-weight: bold;
        }

        .status-completed {
            color: green;
            font-weight: bold;
        }

        .status-failed {
            color: red;
            font-weight: bold;
        }
    </style>
</head>

<body>
<?php include 'loader.php'; ?>

    <?php include 'nav.php'; ?>

    <div class="form-container">
        <h5>Track Your Money Order</h5>
        <form action="" method="POST">
            <div class="mb-3">
                <label for="tracking_id" class="form-label">Tracking ID</label>
                <input type="text" class="form-control" id="tracking_id" name="tracking_id" placeholder="Enter your Tracking ID" required>
            </div>
            <button type="submit" name="track" class="btn btn-primary w-100">
                Track Order <i class="fas fa-search"></i>
            </button>
        </form>

        <?php if (!empty($error_message)): ?>
            <p class="error-message"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>

        <?php if ($order_details): ?>
            <div class="order-details">
                <h6 class="text-center">Order Details</h6>
                <p><strong>Tracking ID:</strong> <?php echo htmlspecialchars($order_details['track_id']); ?></p>
                <p><strong>Sender Name:</strong> <?php echo htmlspecialchars($order_details['sender_name']); ?></p>
                <p><strong>Receiver Name:</strong> <?php echo htmlspecialchars($order_details['receiver_name']); ?></p>
                <p><strong>Amount:</strong> ₹<?php echo htmlspecialchars($order_details['amount']); ?> INR</p>
                <p><strong>Status:</strong>
                    <?php
                    $status = $order_details['status'];
                    if ($status === 'pending') {
                        echo '<span class="status-pending">Pending</span>';
                    } elseif ($status === 'completed') {
                        echo '<span class="status-completed">Completed</span>';
                    } elseif ($status === 'failed') {
                        echo '<span class="status-failed">Failed</span>';
                    }
                    ?>
                </p>
                <p><strong>Created At:</strong> <?php echo htmlspecialchars($order_details['created_at']); ?></p>
            </div>
        <?php endif; ?>
    </div>

    <?php include 'footer.php'; ?>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>