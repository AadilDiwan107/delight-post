<!-- footer.php -->
<footer class="bg-dark text-white py-4 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h5>About Us</h5>
                <p>
                    Delight is a platform designed to provide users with seamless access to services and resources.
                </p>
            </div>
            <div class="col-md-3">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white text-decoration-none">Home</a></li>
                    <li><a href="about.php" class="text-white text-decoration-none">About</a></li>
                    <li><a href="contact.php" class="text-white text-decoration-none">Contact</a></li>
                    <li><a href="rlogin.php" class="text-white text-decoration-none">Rider login</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>Contact Us</h5>
                <p>Email: support@delight.com</p>
                <p>Phone: +123 456 7890</p>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col text-center">
                <p>&copy; <?php echo date("Y"); ?> Delight. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>