<?php
session_start();
// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user details
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?"); // Fetch all columns
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc(); // Fetch all user details
} else {
    // User not found, redirect to login
    header("Location: login.php");
    exit();
}

// Fetch the number of parcels booked by the user
$parcel_count_sql = "SELECT COUNT(*) AS parcel_count FROM parcels WHERE user_id = ?";
$stmt = $conn->prepare($parcel_count_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$parcel_result = $stmt->get_result();
$parcel_data = $parcel_result->fetch_assoc();
$parcel_count = $parcel_data['parcel_count'] ?? 0; // Default to 0 if no parcels are found

$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom Welcome Message Styles */
        h1 {
            text-align: center;
            color: #2575fc;
            font-size: 2rem;
            margin-bottom: 20px;
        }

        p {
            font-size: 1.2rem;
            line-height: 1.6;
            color: #343a40;
            text-align: left;
            /* Align text to the left */
        }

        .btn-logout {
            background-color: #dc3545;
            border: none;
            font-size: 1rem;
            font-weight: bold;
            padding: 10px;
            border-radius: 10px;
            transition: background-color 0.3s ease-in-out;
            display: block;
            margin: 20px auto;
            width: fit-content;
        }

        .btn-logout:hover {
            background-color: #b02a37;
        }
    </style>
</head>

<body>
<?php include 'loader.php'; ?>

    <?php include 'nav.php'; ?>

    <!-- Dashboard Content -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h1>Hello, <?php echo htmlspecialchars($user['name']); ?>!</h1>

                <!-- Display User Details -->
                <p><strong>Name:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone'] ?? 'Not provided'); ?></p>
                <p><strong>Parcels Booked:</strong> <?php echo htmlspecialchars($parcel_count); ?></p>

                <a href="logout.php" class="btn btn-logout">Logout</a>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</html>