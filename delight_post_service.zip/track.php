<?php
session_start(); // Start the session (optional if not using login)

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";

// Establish connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$tracking_id = '';
$parcel_details = null;
$error_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the tracking ID from the form
    $tracking_id = trim($_POST['tracking_id']);

    // Validate the tracking ID
    if (empty($tracking_id)) {
        $error_message = "Please enter a valid Tracking ID.";
    } else {
        // Query the database for the parcel details
        $sql = "SELECT * FROM parcels WHERE track_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $tracking_id); // Bind the tracking ID parameter
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Fetch the parcel details
            $parcel_details = $result->fetch_assoc();
        } else {
            $error_message = "No parcel found with the provided Tracking ID.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Parcel</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        h3 {
            text-align: center;
            color: #343a40;
            margin-bottom: 30px;
        }

        .input-group {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .form-control {
            border: none;
            box-shadow: none;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .card {
            margin-top: 20px;
            border: none;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .card-header {
            background-color: #007bff;
            color: white;
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            border-radius: 8px 8px 0 0;
        }

        .card-body p {
            margin-bottom: 10px;
            font-size: 14px;
            color: #495057;
        }

        .card-body p strong {
            color: #343a40;
            font-weight: bold;
        }

        .alert {
            margin-top: 20px;
            border-radius: 8px;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 12px;
            color: #aaa;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
<?php include 'loader.php'; ?>

    <?php include 'nav.php'; ?>

    <div class="container">
        <h3><i class="fas fa-truck"></i> Track Your Parcel</h3>

        <!-- Tracking Form -->
        <form method="POST" action="">
            <div class="input-group mb-3">
                <input type="text" class="form-control" name="tracking_id" placeholder="Enter Tracking ID" value="<?php echo htmlspecialchars($tracking_id); ?>" required>
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Track</button>
            </div>
        </form>

        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger" role="alert">
                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php elseif ($parcel_details): ?>
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-box"></i> Parcel Details
                </div>
                <div class="card-body">
                    <p><strong>Tracking ID:</strong> <?php echo htmlspecialchars($parcel_details['track_id']); ?></p>
                    <p><strong>Sender Name:</strong> <?php echo htmlspecialchars($parcel_details['sender_name']); ?></p>
                    <p><strong>Receiver Name:</strong> <?php echo htmlspecialchars($parcel_details['receiver_name']); ?></p>
                    <p><strong>sender Address:</strong> <?php echo htmlspecialchars($parcel_details['sender_address']); ?></p>
                    <p><strong>Receiver Address:</strong> <?php echo htmlspecialchars($parcel_details['receiver_address']); ?></p>
                    <p><strong>Parcel Weight:</strong> <?php echo htmlspecialchars($parcel_details['parcel_weight']); ?> kg</p>
                    <p><strong>Parcel Type:</strong> <?php echo htmlspecialchars($parcel_details['parcel_type']); ?></p>
                    <p><strong>Status:</strong>
                        <?php
                        $status = $parcel_details['status'] ?? 'Pending';
                        $status_class = match ($status) {
                            'Pending' => 'text-warning',
                            'Shipped' => 'text-info',
                            'Delivered' => 'text-success',
                            default => 'text-secondary'
                        };
                        echo "<span class='$status_class'><i class='fas fa-circle'></i> <b>$status</b></span>";
                        ?>
                    </p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Footer -->

    </div>
    <?php include 'footer.php'; ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>