<?php
session_start();

// Redirect to login page if rider is not logged in
if (!isset($_SESSION['rider_id'])) {
    header("Location: rlogin.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch rider details
$rider_id = $_SESSION['rider_id'];
$sql = "SELECT * FROM riders WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $rider_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $rider = $result->fetch_assoc();
} else {
    header("Location: logout.php");
    exit();
}

// Fetch all parcels (no filtering by rider_id)
$parcel_sql = "SELECT * FROM parcels"; // Query to fetch all parcels
$parcel_stmt = $conn->prepare($parcel_sql);
$parcel_stmt->execute();
$parcel_result = $parcel_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rider Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Footer Styles */
        .footer {
            background-color: #f8f9fa;
            padding: 20px 0;
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #6c757d;
            border-top: 1px solid #ddd;
        }
        .footer a {
            color: #007bff;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <!-- Navbar for Admin Page -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <!-- Brand Logo -->
            <a class="navbar-brand" href="admin.php">
                <i class="fas fa-motorcycle"></i> Rider Panel
            </a>

            <!-- Toggler Button for Mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar Links -->
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="rider_delivery.php">
                            <i class="fas fa-chart-bar"></i> Deliveries
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <h2 class="text-center">Welcome, <?php echo htmlspecialchars($rider['rider_name']); ?>!</h2>
        <div class="card mt-4">
            <div class="card-body">
                <p><strong>Email:</strong> <?php echo htmlspecialchars($rider['rider_email']); ?></p>
                <p><strong>Phone:</strong> <?php echo htmlspecialchars($rider['rider_phone']); ?></p>
                <p><strong>License Number:</strong> <?php echo htmlspecialchars($rider['license_number']); ?></p>
                <p><strong>Status:</strong> <?php echo htmlspecialchars($rider['status']); ?></p>
                <a href="logout.php" class="btn btn-danger w-100 mb-3">Logout</a>

                <!-- Display Parcels -->
                <h4 class="mt-4">All Parcels</h4>
                <?php if ($parcel_result->num_rows > 0): ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Parcel ID</th>
                                <th>Sender Name</th>
                                <th>Recipient Name</th>
                                <th>Parcel Take Location</th>
                                <th>Parcel Delivery Location</th>
                                <th>Status</th>
                                <th>Action</th> <!-- New column for the button -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($parcel = $parcel_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($parcel['id']); ?></td>
                                    <td><?php echo htmlspecialchars($parcel['sender_name']); ?></td>
                                    <td><?php echo htmlspecialchars($parcel['receiver_name']); ?></td>
                                    <td><?php echo htmlspecialchars($parcel['sender_location']); ?></td>
                                    <td><?php echo htmlspecialchars($parcel['receiver_location']); ?></td>
                                    <td><?php echo htmlspecialchars($parcel['status']); ?></td>
                                    <td>
                                        <?php if ($parcel['status'] === 'pending'): ?>
                                            <!-- Button to take delivery -->
                                            <form action="rider_delivery.php" method="POST" style="display:inline;">
                                                <input type="hidden" name="parcel_id" value="<?php echo htmlspecialchars($parcel['id']); ?>">
                                                <button type="submit" class="btn btn-primary btn-sm">Take Delivery</button>
                                            </form>
                                        <?php elseif ($parcel['status'] === 'delivered'): ?>
                                            <span class="text-success">Delivered</span>
                                        <?php else: ?>
                                            <!-- Button to redirect to rider_delivery.php -->
                                            <form action="rider_delivery.php" method="POST" style="display:inline;">
                                                <input type="hidden" name="parcel_id" value="<?php echo htmlspecialchars($parcel['id']); ?>">
                                                <button type="submit" class="btn btn-primary btn-sm">Take Delivery</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-muted">No parcels available.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Delight Private Limited. All rights reserved. |
                <a href="alogin.php">Admin Login</a> |
                <a href="#">Terms of Service</a>
            </p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>