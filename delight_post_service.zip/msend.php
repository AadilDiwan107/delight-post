<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start(); // Start the session to access user data

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";

// Database connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send'])) {

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        echo "
        <script>
            alert('You must be logged in to send a money order.');
            document.location.href='login.php'; // Redirect to login page
        </script>";
        exit();
    }

    // Retrieve the logged-in user's ID
    $user_id = $_SESSION['user_id'];

    // Collect and sanitize form data
    $sender_name = trim($_POST['sender_name']);
    $sender_email = trim($_POST['sender_email']);
    $sender_transaction_id = trim($_POST['sender_transaction_id']);
    $sender_location = trim($_POST['sender_location']);
    $sender_address = trim($_POST['sender_address']);

    $receiver_name = trim($_POST['receiver_name']);
    $receiver_email = trim($_POST['receiver_email']);
    $receiver_transaction_id = trim($_POST['receiver_transaction_id']);
    $receiver_location = trim($_POST['receiver_location']);
    $receiver_address = trim($_POST['receiver_address']);

    $amount = floatval($_POST['amount']);

    // Generate a unique tracking ID (5-digit number + special character)
    $tracking_number = str_pad(rand(0, 99999), 5, '0', STR_PAD_LEFT); // 5-digit random number
    $special_characters = ['!', '@', '#', '$', '%', '^', '&', '*']; // Array of special characters
    $random_special_character = $special_characters[array_rand($special_characters)]; // Randomly select one
    $tracking_id = $tracking_number . $random_special_character; // Combine number and special character

    // Insert money order details into the database with the tracking ID and user ID
    $insert_sql = "INSERT INTO money_orders (
        sender_name, sender_email, sender_transaction_id, sender_location, sender_address,
        receiver_name, receiver_email, receiver_transaction_id, receiver_location, receiver_address,
        amount, status, created_at, track_id, user_id
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW(), ?, ?)";

    $stmt = $conn->prepare($insert_sql);

    // Bind parameters
    $stmt->bind_param(
        "ssssssssssdsi", // Updated type definition string to match 14 variables
        $sender_name,
        $sender_email,
        $sender_transaction_id,
        $sender_location,
        $sender_address,
        $receiver_name,
        $receiver_email,
        $receiver_transaction_id,
        $receiver_location,
        $receiver_address,
        $amount,
        $tracking_id,
        $user_id // Bind the user_id
    );

    if ($stmt->execute()) {

        // Send confirmation email using PHPMailer
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'AadilDiwan107@gmail.com'; // Replace with your email
            $mail->Password = 'ctfoqugwfjkxkbzq'; // Replace with your app password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;

            $mail->setFrom('AadilDiwan107@gmail.com', 'Delight Private Limited');
            $mail->addAddress($sender_email); // Send to sender's email
            $mail->addAddress($receiver_email); // Send to receiver's email
            $mail->isHTML(true);
            $mail->Subject = 'Money Order Confirmation';

            // Constructing a well-structured, professional email body with CSS
            $mail->Body = "
            <html>
            <head>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f4f7fc;
                        color: #333;
                        padding: 20px;
                    }
                    .email-container {
                        background-color: #ffffff;
                        border-radius: 8px;
                        padding: 30px;
                        border: 1px solid #ddd;
                        max-width: 600px;
                        margin: 0 auto;
                    }
                    .header {
                        background-color: #007bff;
                        color: white;
                        padding: 20px;
                        text-align: center;
                        border-radius: 8px 8px 0 0;
                    }
                    .content {
                        margin-top: 20px;
                    }
                    .footer {
                        text-align: center;
                        margin-top: 30px;
                        font-size: 12px;
                        color: #aaa;
                    }
                    .button {
                        background-color: #007bff;
                        color: white;
                        padding: 12px 30px;
                        border-radius: 5px;
                        text-decoration: none;
                    }
                    .button:hover {
                        background-color: #0056b3;
                    }
                </style>
            </head>
            <body>
                <div class='email-container'>
                    <div class='header'>
                        <h2>Money Order Confirmation</h2>
                    </div>
                    <div class='content'>
                        <p>Hello <strong>$sender_name</strong> and <strong>$receiver_name</strong>,</p>
                        <p>Your money order has been successfully sent with the following details:</p>
                        <ul>
                            <li><strong>Tracking ID:</strong> $tracking_id</li>
                            <li><strong>Sender Name:</strong> $sender_name</li>
                            <li><strong>Receiver Name:</strong> $receiver_name</li>
                            <li><strong>Amount:</strong> ₹$amount INR</li>
                            <li><strong>Status:</strong> Pending</li>
                        </ul>
                         <p>Thank you for choosing us!</p>
                         <p>If you have any questions or need further assistance, please don't hesitate to contact us at <a href='mailto:support@Delight.com'>support@Delight.com</a>.</p>
                        <p>Thank you for your trust and support!</p>
                        <p>Best regards,<br><strong>Delight Private Limited</strong></p>
                    </div>
                    <div class='footer'>
                        <p>For support, contact us at <a href='mailto:support@Delight.com'>support@Delight.com</a></p>
                    </div>
                </div>
            </body>
            </html>
            ";

            // Send the email
            $mail->send();

            // Redirect to money orders page after successful booking
            echo "
            <script>
                alert('Money order sent successfully! Your Tracking ID is: $tracking_id. Redirecting to Orders page...');
                document.location.href='money_orders.php';
            </script>";
        } catch (Exception $e) {
            echo "
            <script>
                alert('Error sending email: {$mail->ErrorInfo}');
                document.location.href='index.php';
            </script>
            ";
        }
    } else {
        echo "
        <script>
            alert('Error inserting data: {$conn->error}');
            document.location.href = 'index.php';
        </script>
        ";
    }
}
?>