<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('You must be logged in to cancel a parcel.'); window.location.href='login.php';</script>";
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if parcel_id is set
if (isset($_POST['parcel_id'])) {
    $parcel_id = $conn->real_escape_string($_POST['parcel_id']);
    
    // Update the parcel status to 'Cancelled'
    $sql = "UPDATE parcels SET status = 'Cancelled' WHERE id = '$parcel_id' AND user_id = '{$_SESSION['user_id']}'";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Parcel cancelled successfully.'); window.location.href='parcels.php';</script>";
    } else {
        echo "<script>alert('Error cancelling parcel: " . $conn->error . "'); window.location.href='my_ordeparcelsrs.php';</script>";
    }
} else {
    echo "<script>alert('Invalid request.'); window.location.href='parcels.php';</script>";
}

$conn->close();
?>