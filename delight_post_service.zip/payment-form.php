<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fake Payment Gateway</title>
</head>
<body>

<h2>Fake Payment Gateway</h2>

<form action="process_payment.php" method="POST">
    <label for="card_number">Card Number:</label><br>
    <input type="text" id="card_number" name="card_number" required><br><br>

    <label for="exp_date">Expiration Date (MM/YY):</label><br>
    <input type="text" id="exp_date" name="exp_date" required><br><br>

    <label for="amount">Amount:</label><br>
    <input type="number" id="amount" name="amount" value="100" required><br><br>

    <input type="submit" value="Pay Now">
</form>

</body>
</html>
