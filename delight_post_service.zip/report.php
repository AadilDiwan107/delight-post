<?php
// Start session
session_start();

// Redirect to login page if the admin is not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Include the database connection file
require_once 'db.php';

// Fetch parcel counts grouped by status for the chart
$sql = "SELECT status, COUNT(*) AS count FROM parcels GROUP BY status";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

// Initialize arrays to store labels and data for the chart
$status_labels = [];
$status_counts = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $status_labels[] = $row['status']; // e.g., Pending, Shipped, Delivered
        $status_counts[] = $row['count']; // Count of parcels for each status
    }
} else {
    $status_labels = ['No Data'];
    $status_counts = [1];
}

// Fetch all users and their booking counts
$user_sql = "
    SELECT 
        u.id, 
        u.name AS user_name, 
        u.email AS user_email, 
        COUNT(DISTINCT p.id) AS parcel_count, 
        COUNT(DISTINCT m.id) AS money_count 
    FROM 
        users u 
    LEFT JOIN 
        parcels p ON u.id = p.user_id 
    LEFT JOIN 
        money_orders m ON u.id = m.user_id 
    GROUP BY 
        u.id, u.name, u.email
";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$users = $user_result->fetch_all(MYSQLI_ASSOC);

// Fetch area-wise parcel counts
$area_sql = "
    SELECT 
        sender_location AS area, 
        COUNT(*) AS parcel_count 
    FROM 
        parcels 
    GROUP BY 
        sender_location 
    ORDER BY 
        parcel_count DESC
";
$area_stmt = $conn->prepare($area_sql);
$area_stmt->execute();
$area_result = $area_stmt->get_result();
$areas = $area_result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Booking Details</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 1200px;
            margin: 50px auto;
        }

        h3 {
            text-align: center;
            color: #343a40;
            margin-bottom: 30px;
        }

        canvas {
            margin-top: 20px;
        }

        .table-container {
            margin-top: 30px;
        }

        .table th, .table td {
            vertical-align: middle;
            text-align: center;
        }

        .table thead th {
            background-color: #007bff;
            color: white;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>

<body>
    <!-- Navbar for Admin Page -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <!-- Brand Logo -->
            <a class="navbar-brand" href="admin.php">
                <i class="fas fa-tachometer-alt"></i> Admin Panel
            </a>

            <!-- Toggler Button for Mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar Links -->
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">
                            <i class="fas fa-home"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rdata.php">
                            <i class="fas fa-motorcycle"></i> Manage Riders
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="udata.php">
                            <i class="fas fa-users"></i> Manage Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="aparcels.php">
                            <i class="fas fa-box-open"></i> View Parcels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h3><i class="fas fa-chart-pie"></i> Parcel Status Distribution</h3>

        <!-- Canvas for the pie chart -->
        <canvas id="parcelStatusChart"></canvas>

        <!-- User Booking Details Table -->
        <div class="table-container">
            <h4 class="mt-4"><i class="fas fa-users"></i> User Booking Details</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>User Name</th>
                        <th>Email</th>
                        <th>Parcel Orders</th>
                        <th>Money Orders</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($users)): ?>
                        <?php foreach ($users as $index => $user): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($index + 1); ?></td>
                                <td><?php echo htmlspecialchars($user['user_name']); ?></td>
                                <td><?php echo htmlspecialchars($user['user_email']); ?></td>
                                <td><?php echo htmlspecialchars($user['parcel_count']); ?></td>
                                <td><?php echo htmlspecialchars($user['money_count']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center">No users found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Area-Wise Parcel Count Table -->
        <div class="table-container">
            <h4 class="mt-4"><i class="fas fa-map-marker-alt"></i> Area-Wise Parcel Counts</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Area</th>
                        <th>Parcel Count</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($areas)): ?>
                        <?php foreach ($areas as $index => $area): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($index + 1); ?></td>
                                <td><?php echo htmlspecialchars($area['area']); ?></td>
                                <td><?php echo htmlspecialchars($area['parcel_count']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" class="text-center">No parcels found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'footer.php'; ?>

    <!-- Chart.js Script -->
    <script>
        // Data fetched from PHP
        const statusLabels = <?php echo json_encode($status_labels); ?>;
        const statusCounts = <?php echo json_encode($status_counts); ?>;

        // Initialize the pie chart
        const ctx = document.getElementById('parcelStatusChart').getContext('2d');
        const parcelStatusChart = new Chart(ctx, {
            type: 'pie', // Pie chart type
            data: {
                labels: statusLabels, // Labels for the chart
                datasets: [{
                    label: 'Parcel Count',
                    data: statusCounts, // Data for the chart
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.6)', // Red for Pending
                        'rgba(54, 162, 235, 0.6)', // Blue for Shipped
                        'rgba(75, 192, 192, 0.6)' // Green for Delivered
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(75, 192, 192, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += context.raw + ' parcels';
                                return label;
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>

</html>