<?php
session_start();

// Redirect to login page if rider is not logged in
if (!isset($_SESSION['rider_id'])) {
    header("Location: rlogin.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if parcel_id is provided
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['parcel_id'])) {
    $parcel_id = $_POST['parcel_id'];

    // Fetch the selected parcel's details
    $parcel_sql = "SELECT * FROM parcels WHERE id = ?";
    $stmt = $conn->prepare($parcel_sql);
    $stmt->bind_param("i", $parcel_id);
    $stmt->execute();
    $parcel_result = $stmt->get_result();

    if ($parcel_result->num_rows > 0) {
        $parcel = $parcel_result->fetch_assoc();
    } else {
        // Redirect back to the dashboard if parcel not found
        header("Location: rdash.php?error=1");
        exit();
    }
} else {
    // Invalid request
    header("Location: rdash.php?error=1");
    exit();
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $new_status = $_POST['new_status'];
    $parcel_id = $_POST['parcel_id'];

    // Update the parcel's status in the database
    $update_sql = "UPDATE parcels SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("si", $new_status, $parcel_id);

    if ($stmt->execute()) {
        // Check if the new status is 'shipped'
        if ($new_status === 'shipped') {
            // Redirect to the dashboard if status is 'shipped'
            header("Location: rdash.php?success=1");
            exit();
        } else {
            // Refresh the page for other statuses
            header("Location: rider_delivery.php?parcel_id=$parcel_id&success=1");
            exit();
        }
    } else {
        echo "<script>alert('Error updating status. Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rider Delivery</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <!-- Navbar for Admin Page -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <!-- Brand Logo -->
            <a class="navbar-brand" href="admin.php">
                <i class="fas fa-tachometer-alt"></i> Rider Panel
            </a>

            <!-- Toggler Button for Mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar Links -->
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">

                    <li class="nav-item">
                        <a class="nav-link" href="rider_delivery.php">
                            <i class="fas fa-chart-bar"></i> Deleveries
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <h2 class="text-center">Parcel Details</h2>
        <div class="card mt-4">
            <div class="card-body">
                <p><strong>Parcel ID:</strong> <?php echo htmlspecialchars($parcel['id']); ?></p>
                <p><strong>Sender Name:</strong> <?php echo htmlspecialchars($parcel['sender_name']); ?></p>
                <p><strong>Recipient Name:</strong> <?php echo htmlspecialchars($parcel['receiver_name']); ?></p>
                <p><strong>Sender Mobile Number :</strong> <?php echo htmlspecialchars($parcel['sender_mobile']); ?></p>
                <p><strong>Recipient Mobile Number:</strong> <?php echo htmlspecialchars($parcel['sender_mobile']); ?></p>
                <p><strong>Parcel Take Location:</strong> <?php echo htmlspecialchars($parcel['sender_location']); ?></p>
                <p><strong>Parcel Delivery Location:</strong> <?php echo htmlspecialchars($parcel['receiver_location']); ?></p>
                <p><strong>Status:</strong> <?php echo htmlspecialchars($parcel['status']); ?></p>

                <!-- Form to update parcel status -->
                <form action="rider_delivery.php" method="POST" class="mt-3">
                    <input type="hidden" name="parcel_id" value="<?php echo htmlspecialchars($parcel['id']); ?>">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="new_status" class="col-form-label">Change Status:</label>
                        </div>
                        <div class="col-auto">
                            <select name="new_status" id="new_status" class="form-select" required>
                                <option value="pending" <?php echo ($parcel['status'] === 'pending') ? 'selected' : ''; ?>>Pending</option>
                                <option value="shipped" <?php echo ($parcel['status'] === 'shipped') ? 'selected' : ''; ?>>Shipped</option>
                                <option value="delivered" <?php echo ($parcel['status'] === 'delivered') ? 'selected' : ''; ?>>Delivered</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <button type="submit" name="update_status" class="btn btn-primary">Update Status</button>
                        </div>
                    </div>
                </form>

                <a href="rdash.php" class="btn btn-secondary w-100 mt-3">Back to Dashboard</a>
            </div>
        </div>
    </div>
</body>

</html>