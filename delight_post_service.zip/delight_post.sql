-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2025 at 04:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `delight`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `otp` int(6) NOT NULL,
  `status` enum('pending','verified') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `phone`, `email`, `password`, `otp`, `status`, `created_at`, `ip_address`) VALUES
(1, 'admin', '0147852369', 'siroheg393@lxheir.com', '12', 578881, 'verified', '2025-02-27 07:31:56', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `money_orders`
--

CREATE TABLE `money_orders` (
  `id` int(11) NOT NULL,
  `sender_name` varchar(255) NOT NULL,
  `sender_email` varchar(255) NOT NULL,
  `sender_transaction_id` varchar(255) NOT NULL,
  `sender_location` varchar(100) NOT NULL,
  `sender_address` text NOT NULL,
  `receiver_name` varchar(255) NOT NULL,
  `receiver_email` varchar(255) NOT NULL,
  `receiver_transaction_id` varchar(255) NOT NULL,
  `receiver_location` varchar(100) NOT NULL,
  `receiver_address` text NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('pending','completed','failed') DEFAULT 'pending',
  `track_id` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `money_orders`
--

INSERT INTO `money_orders` (`id`, `sender_name`, `sender_email`, `sender_transaction_id`, `sender_location`, `sender_address`, `receiver_name`, `receiver_email`, `receiver_transaction_id`, `receiver_location`, `receiver_address`, `amount`, `status`, `track_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'jack and jones', 'kagacon709@excederm.com', '', 'chikhli', 'x park, luton america', 'adidas', 'cipsijalto@gufum.com', '', 'rankuva', 'london toronto, canada', 500.00, 'pending', '74478!', 4, '2025-03-14 10:01:10', '2025-03-14 10:15:26'),
(2, 'janvi', 'janvikayastha2005@gmail.com', '', 'chikhli', 'sdfghjk', 'aadil', 'amndwn172@gmail.com', '', 'rankuva', 'sdfghjk', 5000.00, 'pending', '12019&', 14, '2025-03-22 05:15:01', '2025-03-22 05:15:01'),
(3, 'janvi', 'janvikayashth@gmail.com', '', 'chikhli', 'qwertyuj', 'aadil', 'amndwn172@gmail.com', '', 'rankuva', 'sdfghjkl', 500.00, 'pending', '46321$', 14, '2025-03-22 05:17:00', '2025-03-22 05:17:00');

-- --------------------------------------------------------

--
-- Table structure for table `parcels`
--

CREATE TABLE `parcels` (
  `id` int(11) NOT NULL,
  `track_id` varchar(10) NOT NULL,
  `sender_name` varchar(255) NOT NULL,
  `sender_email` varchar(255) NOT NULL,
  `sender_mobile` varchar(15) NOT NULL,
  `sender_address` text NOT NULL,
  `sender_location` varchar(50) NOT NULL,
  `receiver_name` varchar(255) NOT NULL,
  `receiver_email` varchar(255) NOT NULL,
  `receiver_mobile` varchar(15) NOT NULL,
  `receiver_address` text NOT NULL,
  `receiver_location` varchar(50) NOT NULL,
  `parcel_weight` decimal(10,2) NOT NULL,
  `parcel_type` enum('normal','sensitive') NOT NULL,
  `status` enum('pending','shipped','delivered') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parcels`
--

INSERT INTO `parcels` (`id`, `track_id`, `sender_name`, `sender_email`, `sender_mobile`, `sender_address`, `sender_location`, `receiver_name`, `receiver_email`, `receiver_mobile`, `receiver_address`, `receiver_location`, `parcel_weight`, `parcel_type`, `status`, `created_at`, `user_id`, `price`) VALUES
(1, '515', 'aadil', 'majoha9840@jarars.com', '0147852369', 'jwisj', 'chikhli', 'amaan', 'amndwn172@gmail.com', '0236589741', 'kjsh', 'rankuva', 1.00, 'sensitive', 'delivered', '2025-02-26 05:05:29', 0, 0.00),
(2, '222', 'abc', 'majoha9840@jarars.com', '0147852369', 'khgf', 'chikhli', 'AMAAN', 'amndwn@gmail.com', '0123654788', 'ghgiuy', 'rankuva', 1.00, 'sensitive', 'delivered', '2025-02-26 09:09:41', 0, 0.00),
(3, '337', 'abc', 'majoha9840@jarars.com', '0147852369', 'khgf', 'chikhli', 'AMAAN', 'amndwn@gmail.com', '0123654788', 'ghgiuy', 'rankuva', 1.00, 'sensitive', 'delivered', '2025-02-26 09:10:20', 2, 0.00),
(4, '680', 'abc', 'majoha9840@jarars.com', '0147852369', 'khgf', 'chikhli', 'AMAAN', 'amndwn172@gmail.com', '0123654788', 'ghgiuy', 'rankuva', 1.00, 'sensitive', 'shipped', '2025-02-26 09:11:30', 0, 0.00),
(5, '110', 'fexoj', 'fexoj27186@btcours.com', '01478523969', 'idiajf', 'chikhli', 'dykypi', 'dykypi@logsmarter.net', '0236589741', ';ldfgm', 'rankuva', 5.00, 'sensitive', 'delivered', '2025-02-26 12:47:48', 2, 0.00),
(6, '330', 'sundaram', 'malisundaram01@gmail.com', '0147852369', 'ieasfyug', 'rankuva', 'aadil', 'aadildiwan107@gmail.com', '0147852369', 'ujygf', 'rankuva', 4.00, 'sensitive', 'pending', '2025-02-27 05:57:35', 4, 0.00),
(7, '591', 'khjgy', 'azizalzayed@uz8.net', '011778965489', 'harangaam sidat faliya ', 'rankuva', 'kfTLJKHHJ', 'haraje1514@egvoo.com', '23144777', 'chikhl;i ', 'chikhli', 1.00, 'sensitive', 'pending', '2025-02-28 13:32:28', 4, 0.00),
(8, '483', 'aziz', 'ayaankhalifa4432@gmail.com', '0147852399', 'chikhli nadi faliya', 'chikhli', 'aadil', 'amndwn172@gmil.com', '7016951138', 'harangaam sidat faliya', 'rankuva', 1.00, 'sensitive', 'delivered', '2025-03-01 04:38:50', 8, 0.00),
(9, '257', 'ayaan', 'ayaankhalifa4432@gmail.com', '0147852399', 'chikhli nadi faliya', 'chikhli', 'aadil', 'amndwn172@gmail.com', '7016951138', 'harangaam sidat faliya', 'rankuva', 1.00, 'sensitive', 'pending', '2025-03-01 04:43:54', 4, 0.00),
(10, '', 'xyz', 'haseho6826@egvoo.com', '0321748596', 'abc xyz', 'chikhli', 'abc', 'cejula@asciibinder.net', '0147852369', 'abc xyz', 'rankuva', 1.00, 'normal', 'pending', '2025-03-05 04:58:14', 4, 0.00),
(16, '360', 'abc', 'haseho6826@egvoo.com', '01478520369', 'xyz', 'chikhli', 'xyz', 'cejula@asciibinder.net', '0321475869', 'abc', 'rankuva', 1.00, 'normal', 'shipped', '2025-03-05 06:41:45', 4, 0.00),
(17, '819', 'abc', 'haseho6826@egvoo.com', '01478520369', 'xyz', 'chikhli', 'xyz', 'judilu@polkaroad.net', '0321475869', 'abc', 'rankuva', 1.00, 'normal', 'shipped', '2025-03-05 06:49:28', 0, 0.00),
(18, '402', 'bronco', 'bronc.aarav@thefluent.org', '1234567890', 'asdfghjkdcvbnkuh,dfgbhnjmk,ldcfvgbhn14785', 'chikhli', 'wisoj', 'wisoje4160@egvoo.com', '0987654321', 'sexdrcfvtgbhnjmkkjnhg,s4cftvgybh,zxdcfvg258', 'rankuva', 1.00, 'sensitive', 'pending', '2025-03-06 08:05:07', 4, 0.00),
(19, '252', 'bronco', 'bronc.aarav@thefluent.org', '1234567890', 'asdfghjkdcvbnkuh,dfgbhnjmk,ldcfvgbhn14785', 'chikhli', 'wisoj', 'wisoje4160@egvoo.com', '0987654321', 'sexdrcfvtgbhnjmkkjnhg,s4cftvgybh,zxdcfvg258', 'rankuva', 1.00, 'sensitive', 'delivered', '2025-03-06 08:09:49', 4, 0.00),
(20, '601', 'bronco', 'bronc.aarav@thefluent.org', '1234567890', 'asdfghjkdcvbnkuh,dfgbhnjmk,ldcfvgbhn14785', 'chikhli', 'wisoj', 'wisoje4160@egvoo.com', '0987654321', 'sexdrcfvtgbhnjmkkjnhg,s4cftvgybh,zxdcfvg258', 'rankuva', 1.00, 'normal', 'shipped', '2025-03-06 08:11:30', 4, 0.00),
(21, '979', 'aadil', 'bugnejukni@gufum.com', '014785269', 'qwerty', 'chikhli', 'xyz', 'tavewi4542@kaiav.com', '14444', 'dsdg', 'rankuva', 2.00, 'normal', 'pending', '2025-03-13 10:15:15', 4, 0.00),
(22, '916', 'abc', 'wikox44823@excederm.com', '147853692', 'chikhli', 'chikhli', 'abc', 'scarab7219@spinly.net', '1485723690', 'rankuva', 'rankuva', 1.00, 'normal', 'pending', '2025-03-17 07:38:31', 4, 0.00),
(23, '677', 'diya', 'diyupatel375@gmail.com', '12345678889', 'qwedrtfgyhazsXDC', 'chikhli', 'ASDFGHJ', 'wikox44823@excederm.com', '1234567890', 'sdfghjpoiuhgfdfghj', 'rankuva', 1.00, 'normal', 'delivered', '2025-03-18 05:11:14', 13, 0.00),
(24, '588', 'janvi', 'janvikayastha2005@gmail.com', '0147852369', 'abc,123', 'chikhli', 'abc', 'rexon30403@hikuhu.com', '0123654789', 'xyz,789', 'rankuva', 2.00, 'sensitive', 'pending', '2025-03-22 05:12:02', 14, 0.00),
(25, '475', 'abc', 'fowl4521@flyzy.net', '1234567890', 'zaestxrdycfuvgbihnj', 'rankuva', 'xyz', 'keroyaw780@amgens.com', '00987654321', 'xtcryvtuby', 'harangam', 1.00, 'normal', 'delivered', '2025-03-24 05:20:16', 2, 0.00),
(26, '570', 'abc', 'earthworm81345@mailnuo.com', '1234567890', 'zrsxdtcfyvgubh', 'chikhli', 'xyz', 'keroyaw780@amgens.com', '0987654321', 'zrxtcyvgbiuhn', 'rankuva', 1.00, 'sensitive', 'pending', '2025-03-24 05:53:46', 2, 0.00),
(27, '811', 'aaa', 'keroyaw780@amgens.com', '1234567890', 'zsexrdctfvgybhu', 'rankuva', 'zzz', 'hedgehog79490@driftz.net', '0987654321', 'azesxrdctfvgyubh', 'harangam', 1.00, 'sensitive', 'pending', '2025-03-24 06:10:31', 2, 0.00),
(28, '334', 'dolphin', 'dolphin8577@dotzi.net', '0125478963', 'zsxdcfyvgubhinjom', 'rankuva', 'keroyaw', 'keroyaw780@amgens.com', '0956743218', 'zxcfvgbhudcfgh', 'harangam', 2.00, 'sensitive', 'pending', '2025-03-25 09:47:13', 2, 0.00),
(29, '713', 'keroya', 'keroyaw780@amgens.com', '0987612345', 'xsdrctfvgybhun', 'chikhli', 'dolphin', 'dolphin8577@dotzi.net', '123456780987', 'szxrdctfvygbuhnijmokjiuhbygt', 'rankuva', 1.00, 'sensitive', 'pending', '2025-03-25 09:50:03', 2, 0.00),
(30, '904', 'keroya', 'keroyaw780@amgens.com', '0987612345', 'xsdrctfvgybhun', 'rankuva', 'dolphin', 'dolphin8577@dotzi.net', '123456780987', 'szxrdctfvygbuhnijmokjiuhbygt', 'harangam', 1.00, 'sensitive', 'pending', '2025-03-25 10:07:50', 2, 0.00),
(31, '356', 'keroya', 'keroyaw780@amgens.com', '0987612345', 'xsdrctfvgybhun', 'chikhli', 'dolphin', 'dolphin8577@dotzi.net', '123456780987', 'szxrdctfvygbuhnijmokjiuhbygt', 'rankuva', 1.00, 'sensitive', 'pending', '2025-03-25 10:12:18', 2, 0.00),
(32, '684', 'asdf', 'keroyaw780@amgens.com', '1234567890', 'rsdxtcfyvgubhi', 'rankuva', 'qwerty', 'dugong97446@dotzi.net', '0987654321', 'rzsxdtcfvygbuhnj', 'harangam', 1.00, 'sensitive', 'pending', '2025-03-25 10:16:58', 2, 0.00),
(33, '354', 'harsh', 'vaxoy98098@amgens.com', '9081111374', 'kukeri chikhi', 'rankuva', 'jayesh', 'partridge4330@dotup.net', '8956894875', 'vasdefad', 'harangam', 1.00, 'sensitive', 'delivered', '2025-03-26 06:16:22', 2, 0.00),
(34, '808', 'abc', 'mockingbird4204@vibzi.net', '1234567890', 'dtxdds', 'rankuva', 'xyz', 'vaxoy98098@amgens.com', '0987654321', 'sdigyeq', 'harangam', 2.00, 'normal', 'delivered', '2025-03-26 07:06:00', 2, 0.00),
(35, '315', 'qwerty', 'vaxoy98098@amgens.com', '987654321', 'aqswdefrtghyujkiol', 'rankuva', 'asad', 'shrike78529@spinly.net', '1234567890', 'aqwsdefrtgyh', '0', 1.00, 'normal', 'pending', '2025-03-27 00:03:02', 2, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('Pending','Completed','Failed','Refunded') NOT NULL DEFAULT 'Pending',
  `payment_id` varchar(50) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `card_number` varchar(16) DEFAULT NULL,
  `exp_date` varchar(5) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `card_number`, `exp_date`, `amount`, `status`, `transaction_id`, `created_at`) VALUES
(1, '4111 1111 1111 1', '12/25', 100.00, 'Success', 'TXN133405E53700BA09', '2025-03-17 11:33:37'),
(11, '5105 1051 0510 5', '12/25', 100.00, 'Success', 'TXNA596469450F95A4A', '2025-03-18 05:21:28'),
(12, '5105 1051 0510 5', '12/25', 100.00, 'Success', 'TXN9CC5BD59FBD48110', '2025-03-18 05:22:24'),
(13, '5105 1051 0510 5', '12/25', 100.00, 'Failure', 'TXNA60F88D4C283FCE7', '2025-03-18 05:22:30');

-- --------------------------------------------------------

--
-- Table structure for table `riders`
--

CREATE TABLE `riders` (
  `id` int(11) NOT NULL,
  `rider_name` varchar(255) NOT NULL,
  `rider_email` varchar(255) NOT NULL,
  `rider_phone` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `otp` int(11) NOT NULL,
  `status` enum('pending','verified') DEFAULT 'pending',
  `otp_send_time` datetime DEFAULT current_timestamp(),
  `ip` varchar(45) NOT NULL,
  `license_number` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `riders`
--

INSERT INTO `riders` (`id`, `rider_name`, `rider_email`, `rider_phone`, `password`, `otp`, `status`, `otp_send_time`, `ip`, `license_number`) VALUES
(1, 'xrider', 'cejula@ibinder.net', '7016951138', '0', 344727, 'pending', '2025-03-04 11:12:37', '::1', 'DL123456789'),
(3, 'abc', 'cejula@asciibinder.net', '0125478963', '0', 202298, 'verified', '2025-03-04 11:33:33', '::1', 'GJ123456789');

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `id` int(11) NOT NULL,
  `sender_location` varchar(255) NOT NULL,
  `receiver_location` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `sender_location`, `receiver_location`, `price`, `created_at`) VALUES
(1, 'rankuva', 'harangam', 50.00, '2025-03-24 01:54:34'),
(2, 'chikhli', 'rankuva', 70.00, '2025-03-24 01:59:19');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `transaction_type` enum('add','withdraw') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `amount`, `transaction_type`, `created_at`) VALUES
(1, 2, 50.00, 'add', '2025-03-03 08:05:53'),
(2, 2, 50.00, 'add', '2025-03-03 08:06:01'),
(3, 2, 50.00, 'add', '2025-03-03 08:07:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `otp` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `otp_send_time` datetime NOT NULL DEFAULT current_timestamp(),
  `ip` varchar(45) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `password`, `otp`, `ip_address`, `created_at`, `status`, `otp_send_time`, `ip`, `amount`) VALUES
(1, 'aman', '1048523697', 'amndwn172@gmailc.om', '0', 441934, '', '2025-02-25 09:29:15', 'pending', '2025-02-25 14:59:15', '::1', 0.00),
(2, 'aman', '0147852369', 'amndwn172@gmail.com', '0', 441934, '', '2025-02-25 09:29:56', 'verified', '2025-02-25 14:59:56', '::1', 650.00),
(4, 'sundaram', '0147852369', 'malisundaram01@gmail.com', '01', 846988, '', '2025-02-27 05:54:49', 'verified', '2025-02-27 11:24:49', '::1', 0.00),
(7, 'hareja', '0147823695', 'haraje1514@egvoo.com', '00', 457718, '', '2025-02-28 13:39:35', 'verified', '2025-02-28 19:09:35', '::1', 0.00),
(8, 'ayaan khalifa', '0147852369', 'ayaankhalifa4432@gmail.com', '69', 513830, '', '2025-03-01 04:35:14', 'verified', '2025-03-01 10:05:14', '::1', 0.00),
(9, 'pinal', '014785239', 'pinaldesai09101999@gmail.com', '0', 688603, '', '2025-03-01 06:59:40', 'verified', '2025-03-01 12:29:40', '::1', 0.00),
(10, 'aadio', '0147852369', 'aadildiwan107@gmail.com', '0', 855061, '', '2025-03-01 07:32:39', 'verified', '2025-03-01 13:02:39', '::1', 0.00),
(11, 'xrider', '0147852369', 'cejula@asciibinder.net', '0', 344727, '', '2025-03-04 05:35:05', 'verified', '2025-03-04 11:05:05', '::1', 0.00),
(12, 'xr', '0147852369', 'haseho6826@egvoo.com', '0', 243976, '', '2025-03-04 05:56:09', 'verified', '2025-03-04 11:26:09', '::1', 0.00),
(13, 'Diya', '1234567890', 'diyupatel375@gmail.com', 'd02', 507805, '', '2025-03-18 05:06:47', 'verified', '2025-03-18 10:36:47', '::1', 0.00),
(14, 'janvi', '9313540880', 'janvikayastha2005@gmail.com', 'janvi@1234', 601456, '', '2025-03-22 05:05:57', 'verified', '2025-03-22 10:35:57', '::1', 0.00),
(15, 'wyz', '014852369', 'rexon30403@hikuhu.com', '001', 554888, '', '2025-03-22 05:22:17', 'verified', '2025-03-22 10:52:17', '::1', 0.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `money_orders`
--
ALTER TABLE `money_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `track_id` (`track_id`);

--
-- Indexes for table `parcels`
--
ALTER TABLE `parcels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `track_id` (`track_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payment_id` (`payment_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `riders`
--
ALTER TABLE `riders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rider_email` (`rider_email`);

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `money_orders`
--
ALTER TABLE `money_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `parcels`
--
ALTER TABLE `parcels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `riders`
--
ALTER TABLE `riders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
