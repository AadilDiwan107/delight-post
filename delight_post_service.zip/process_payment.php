<?php
// Fake Payment Gateway - process_payment.php

// Database connection (use your own database credentials here)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST data from the payment form
$card_number = $_POST['card_number'];
$exp_date = $_POST['exp_date'];
$amount = $_POST['amount'];

// Validate inputs (very basic validation)
if (empty($card_number) || empty($exp_date) || empty($amount)) {
    echo "All fields are required.";
    exit;
}

// Simulate a payment processing outcome (success or failure)
$payment_successful = rand(0, 1) == 1; // Randomly return success or failure

// Simulate processing time
sleep(2);

// Generate a random transaction ID for simulation purposes
$transaction_id = "TXN" . strtoupper(bin2hex(random_bytes(8)));

// Prepare the status message
if ($payment_successful) {
    $status = 'Success';
    echo "<h2>Payment Successful</h2>";
    echo "<p>Your payment of $".number_format($amount, 2)." was processed successfully.</p>";
} else {
    $status = 'Failure';
    echo "<h2>Payment Failed</h2>";
    echo "<p>Sorry, your payment could not be processed. Please try again.</p>";
}

// Save payment information in the database (whether successful or failed)
$stmt = $conn->prepare("INSERT INTO payments (card_number, exp_date, amount, status, transaction_id) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $card_number, $exp_date, $amount, $status, $transaction_id);
$stmt->execute();

// Close the connection
$stmt->close();
$conn->close();
?>
