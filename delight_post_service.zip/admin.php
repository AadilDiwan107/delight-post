<?php
// Start session
session_start();

// Redirect to login page if the admin is not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: alogin.php");
    exit;
}

// Include the database connection file
require_once 'db.php';

// Fetch all riders from the database
$sql = "SELECT * FROM riders ORDER BY id DESC"; // Assuming 'id' is the primary key
$result = $conn->query($sql);

// Initialize an array to store rider details
$riders = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $riders[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 1200px;
            margin: 50px auto;
        }

        h3 {
            text-align: center;
            color: #343a40;
            margin-bottom: 30px;
        }

        .table {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .table thead {
            background-color: #007bff;
            color: white;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #aaa;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .logout-btn {
            margin-left: auto;
        }

        /* Card Styling */
        .card-container {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            /* Allow wrapping for smaller screens */
        }

        .card {
            width: 300px;
            text-align: center;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
        }

        .card:hover {
            transform: translateY(-10px);
        }

        .card i {
            font-size: 3rem;
            margin-bottom: 15px;
            color: #007bff;
        }

        .card h5 {
            margin-bottom: 15px;
            color: #343a40;
        }

        .card .btn {
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <!-- Navbar for Admin Page -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <!-- Brand Logo -->
            <a class="navbar-brand" href="admin.php">
                <i class="fas fa-tachometer-alt"></i> Admin Panel
            </a>

            <!-- Toggler Button for Mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar Links -->
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">
                            <i class="fas fa-home"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rdata.php">
                            <i class="fas fa-motorcycle"></i> Manage Riders
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="udata.php">
                            <i class="fas fa-users"></i> Manage Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="aparcels.php">
                            <i class="fas fa-box-open"></i> View Parcels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="report.php">
                            <i class="fas fa-chart-bar"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <h3><i class="fas fa-tachometer-alt"></i> Admin Dashboard</h3>

        <!-- Logout Button -->
        <div class="d-flex justify-content-end mb-3">
            <a href="logout.php" class="btn btn-danger logout-btn">Logout <i class="fas fa-sign-out-alt"></i></a>
        </div>

        <!-- Six Cards Section -->
        <div class="card-container">
            <!-- Card 1: Add Rider -->
            <div class="card">
                <i class="fas fa-user-plus"></i>
                <h5>Add Rider</h5>
                <p>Add a new rider to the system.</p>
                <a href="adduser.php" class="btn btn-primary"><i class="fas fa-plus"></i> Add Rider</a>
            </div>

            <!-- Card 2: View Reports -->
            <div class="card">
                <i class="fas fa-chart-bar"></i>
                <h5>View Reports</h5>
                <p>View detailed reports and analytics.</p>
                <a href="report.php" class="btn btn-success"><i class="fas fa-eye"></i> View Reports</a>
            </div>

            <!-- Card 3: Manage Riders -->
            <div class="card">
                <i class="fas fa-users"></i>
                <h5>Manage Riders</h5>
                <p>Manage all registered riders.</p>
                <a href="amoney.php" class="btn btn-info"><i class="fas fa-cog"></i> Manage Riders</a>
            </div>

            <!-- Card 4: View Rider Data -->
            <div class="card">
                <i class="fas fa-motorcycle"></i>
                <h5>Rider Data</h5>
                <p>View all registered rider details.</p>
                <a href="rdata.php" class="btn btn-warning"><i class="fas fa-eye"></i> View Riders</a>
            </div>

            <!-- Card 5: View User Data -->
            <div class="card">
                <i class="fas fa-user-friends"></i>
                <h5>User Data</h5>
                <p>View all registered user details.</p>
                <a href="udata.php" class="btn btn-secondary"><i class="fas fa-eye"></i> View Users</a>
            </div>

            <!-- Card 6: View Parcel Data -->
            <div class="card">
                <i class="fas fa-box-open"></i>
                <h5>Parcel Data</h5>
                <p>View all parcel details and statuses.</p>
                <a href="aparcels.php" class="btn btn-dark"><i class="fas fa-eye"></i> View Parcels</a>
            </div>
        </div>

        <!-- Riders Table -->
        <?php if (empty($riders)): ?>
            <div class="alert alert-info" role="alert">
                No riders registered at the moment.
            </div>
        <?php else: ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>License Number</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($riders as $rider): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($rider['id']); ?></td>
                            <td><?php echo htmlspecialchars($rider['rider_name']); ?></td>
                            <td><?php echo htmlspecialchars($rider['rider_email']); ?></td>
                            <td><?php echo htmlspecialchars($rider['rider_phone']); ?></td>
                            <td><?php echo htmlspecialchars($rider['license_number']); ?></td>
                            <td>
                                <?php
                                $status = $rider['status'] ?? 'Pending';
                                $status_class = match ($status) {
                                    'Pending' => 'text-warning',
                                    'Verified' => 'text-success',
                                    default => 'text-secondary'
                                };
                                echo "<span class='$status_class'><i class='fas fa-circle'></i> $status</span>";
                                ?>
                            </td>
                            <td>
                                <a href="view_rider.php?id=<?php echo htmlspecialchars($rider['id']); ?>" class="btn btn-sm btn-primary"><i class="fas fa-eye"></i> View</a>
                                <a href="delete_rider.php?id=<?php echo htmlspecialchars($rider['id']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this rider?');"><i class="fas fa-trash"></i> Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <!-- Footer -->
        <div class="footer">
            <p>&copy; 2023 Delight Private Limited. All rights reserved. |
                <a href="#">Privacy Policy</a> |
                <a href="#">Terms of Service</a>
            </p>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>