<?php
// Start session
session_start();

// Redirect to login page if the admin is not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: alogin.php");
    exit;
}

// Include the database connection file
require_once 'db.php';

// Fetch all parcels from the database
$sql = "SELECT * FROM parcels ORDER BY id DESC"; // Assuming 'id' is the primary key
$result = $conn->query($sql);

// Initialize an array to store parcel details
$parcels = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $parcels[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Parcels</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 1200px;
            margin: 50px auto;
        }

        h3 {
            text-align: center;
            color: #343a40;
            margin-bottom: 30px;
        }

        .table {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .table thead {
            background-color: #007bff;
            color: white;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .btn-custom {
            background-color: #007bff;
            border: none;
            transition: background-color 0.3s ease-in-out;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #aaa;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .alert-info {
            text-align: center;
            font-size: 1rem;
            color: #0c5460;
            background-color: #d1ecf1;
            border-color: #bee5eb;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 500px;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            z-index: 9999;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 9998;
        }
    </style>
</head>

<body>
    <!-- Navbar for Admin Page -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <!-- Brand Logo -->
            <a class="navbar-brand" href="admin.php">
                <i class="fas fa-tachometer-alt"></i> Admin Panel
            </a>

            <!-- Toggler Button for Mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar Links -->
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">
                            <i class="fas fa-home"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rdata.php">
                            <i class="fas fa-motorcycle"></i> Manage Riders
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="udata.php">
                            <i class="fas fa-users"></i> Manage Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="aparcels.php">
                            <i class="fas fa-box-open"></i> View Parcels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h3><i class="fas fa-box"></i> All Parcels</h3>

        <!-- Parcels Table -->
        <?php if (empty($parcels)): ?>
            <div class="alert alert-info" role="alert">
                No parcels found.
            </div>
        <?php else: ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User ID</th>
                        <th>Tracking ID</th>
                        <th>Sender Name</th>
                        <th>Receiver Name</th>
                        <th>Sender Location</th>
                        <th>Receiver Location</th>
                        <th>Parcel Weight (kg)</th>
                        <th>Parcel Type</th>
                        <th>Status</th>
                        <th>Created On</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($parcels as $parcel): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($parcel['id']); ?></td>
                            <td><?php echo htmlspecialchars($parcel['user_id']); ?></td>
                            <td><?php echo htmlspecialchars($parcel['track_id']); ?></td>
                            <td><?php echo htmlspecialchars($parcel['sender_name']); ?></td>
                            <td><?php echo htmlspecialchars($parcel['receiver_name']); ?></td>
                            <td><?php echo htmlspecialchars($parcel['sender_address']); ?></td>
                            <td><?php echo htmlspecialchars($parcel['receiver_address']); ?></td>
                            <td><?php echo htmlspecialchars($parcel['parcel_weight']); ?></td>
                            <td><?php echo htmlspecialchars($parcel['parcel_type']); ?></td>
                            <td>
                                <?php
                                $status = $parcel['status'] ?? 'Pending';
                                $status_class = match ($status) {
                                    'Pending' => 'text-warning',
                                    'Shipped' => 'text-info',
                                    'Delivered' => 'text-success',
                                    default => 'text-secondary'
                                };
                                echo "<span class='$status_class'><i class='fas fa-circle'></i> $status</span>";
                                ?>
                            </td>
                            <td><?php echo htmlspecialchars($parcel['created_at']); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary view-btn" 
                                        data-id="<?php echo htmlspecialchars($parcel['id']); ?>"
                                        data-sender-name="<?php echo htmlspecialchars($parcel['sender_name']); ?>"
                                        data-receiver-name="<?php echo htmlspecialchars($parcel['receiver_name']); ?>"
                                        data-sender-address="<?php echo htmlspecialchars($parcel['sender_address']); ?>"
                                        data-receiver-address="<?php echo htmlspecialchars($parcel['receiver_address']); ?>"
                                        data-weight="<?php echo htmlspecialchars($parcel['parcel_weight']); ?>"
                                        data-type="<?php echo htmlspecialchars($parcel['parcel_type']); ?>"
                                        data-status="<?php echo htmlspecialchars($parcel['status']); ?>">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <a href="delete_parcel.php?id=<?php echo htmlspecialchars($parcel['id']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this parcel?');">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <!-- Footer -->
        <div class="footer">
            <p>&copy; 2023 Delight Private Limited. All rights reserved. |
                <a href="#">Privacy Policy</a> |
                <a href="#">Terms of Service</a>
            </p>
        </div>
    </div>

    <!-- Parcel Details Modal -->
    <div class="modal" id="parcelModal">
        <div class="modal-header">
            <h4 class="modal-title"><i class="fas fa-box"></i> Parcel Details</h4>
        </div>
        <form method="POST" action="aparcels.php">
            <input type="hidden" id="parcel_id" name="parcel_id">
            <div class="modal-body">
                <div class="mb-3">
                    <label for="sender_name" class="form-label">Sender Name</label>
                    <input type="text" class="form-control" id="sender_name" name="sender_name" required>
                </div>
                <div class="mb-3">
                    <label for="receiver_name" class="form-label">Receiver Name</label>
                    <input type="text" class="form-control" id="receiver_name" name="receiver_name" required>
                </div>
                <div class="mb-3">
                    <label for="sender_address" class="form-label">Sender Address</label>
                    <input type="text" class="form-control" id="sender_address" name="sender_address" required>
                </div>
                <div class="mb-3">
                    <label for="receiver_address" class="form-label">Receiver Address</label>
                    <input type="text" class="form-control" id="receiver_address" name="receiver_address" required>
                </div>
                <div class="mb-3">
                    <label for="weight" class="form-label">Parcel Weight (kg)</label>
                    <input type="number" step="0.01" class="form-control" id="weight" name="weight" required>
                </div>
                <div class="mb-3">
                    <label for="type" class="form-label">Parcel Type</label>
                    <input type="text" class="form-control" id="type" name="type" required>
                </div>
                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status" required>
                        <option value="Pending">Pending</option>
                        <option value="Shipped">Shipped</option>
                        <option value="Delivered">Delivered</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Save Changes</button>
                <button type="button" class="btn btn-secondary close-modal">Cancel</button>
            </div>
        </form>
    </div>

    <!-- Overlay for Modal -->
    <div class="overlay" id="overlay"></div>

    <!-- JavaScript for Modal -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const modal = document.getElementById("parcelModal");
            const overlay = document.getElementById("overlay");

            // Open the modal when the "View" button is clicked
            document.querySelectorAll(".view-btn").forEach(button => {
                button.addEventListener("click", function () {
                    // Populate the modal fields with parcel details
                    document.getElementById("parcel_id").value = this.getAttribute("data-id");
                    document.getElementById("sender_name").value = this.getAttribute("data-sender-name");
                    document.getElementById("receiver_name").value = this.getAttribute("data-receiver-name");
                    document.getElementById("sender_address").value = this.getAttribute("data-sender-address");
                    document.getElementById("receiver_address").value = this.getAttribute("data-receiver-address");
                    document.getElementById("weight").value = this.getAttribute("data-weight");
                    document.getElementById("type").value = this.getAttribute("data-type");
                    document.getElementById("status").value = this.getAttribute("data-status");

                    // Show the modal and overlay
                    modal.style.display = "block";
                    overlay.style.display = "block";
                });
            });

            // Close the modal when the "Cancel" button or overlay is clicked
            document.querySelectorAll(".close-modal, #overlay").forEach(element => {
                element.addEventListener("click", function () {
                    modal.style.display = "none";
                    overlay.style.display = "none";
                });
            });
        });
    </script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>