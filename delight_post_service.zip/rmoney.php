<?php
session_start();

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user details
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    header("Location: logout.php");
    exit();
}

// Fetch all money orders (no filtering by user_id)
$money_order_sql = "SELECT * FROM money_orders"; // Query to fetch all money orders
$money_order_stmt = $conn->prepare($money_order_sql);
$money_order_stmt->execute();
$money_order_result = $money_order_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Money Order Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <!-- Navbar for Money Order Dashboard -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <!-- Brand Logo -->
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-money-bill-wave"></i> Money Order Panel
            </a>

            <!-- Toggler Button for Mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar Links -->
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="money_order_history.php">
                            <i class="fas fa-history"></i> History
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="text-center">Welcome, <?php echo htmlspecialchars($user['name']); ?>!</h2>
        <div class="card mt-4">
            <div class="card-body">
                <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone']); ?></p>
                <p><strong>Status:</strong> <?php echo htmlspecialchars($user['status']); ?></p>
                <a href="logout.php" class="btn btn-danger w-100 mb-3">Logout</a>

                <!-- Display Money Orders -->
                <h4 class="mt-4">All Money Orders</h4>
                <?php if ($money_order_result->num_rows > 0): ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Tracking ID</th>
                                <th>Sender Name</th>
                                <th>Receiver Name</th>
                                <th>Amount (INR)</th>
                                <th>Status</th>
                                <th>Action</th> <!-- New column for action buttons -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($money_order = $money_order_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($money_order['track_id']); ?></td>
                                    <td><?php echo htmlspecialchars($money_order['sender_name']); ?></td>
                                    <td><?php echo htmlspecialchars($money_order['receiver_name']); ?></td>
                                    <td>₹<?php echo htmlspecialchars(number_format($money_order['amount'], 2)); ?></td>
                                    <td>
                                        <?php
                                        $status = $money_order['status'];
                                        if ($status === 'pending') {
                                            echo '<span class="text-warning">Pending</span>';
                                        } elseif ($status === 'completed') {
                                            echo '<span class="text-success">Completed</span>';
                                        } elseif ($status === 'failed') {
                                            echo '<span class="text-danger">Failed</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if ($money_order['status'] === 'pending'): ?>
                                            <!-- Button to complete the money order -->
                                            <form action="complete_money_order.php" method="POST" style="display:inline;">
                                                <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($money_order['id']); ?>">
                                                <button type="submit" class="btn btn-primary btn-sm">Complete</button>
                                            </form>
                                        <?php elseif ($money_order['status'] === 'completed'): ?>
                                            <span class="text-success">Completed</span>
                                        <?php else: ?>
                                            <span class="text-danger">Failed</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-muted">No money orders available.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>

</html>