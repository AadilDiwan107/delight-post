<?php
session_start(); // Start the session
// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('You must be logged in to view this page.'); window.location.href='login.php';</script>";
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "delight";
// Establish connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the logged-in user's ID
$user_id = $_SESSION['user_id'];
// Query to fetch all parcels booked by the logged-in user
$sql = "SELECT * FROM parcels WHERE user_id = '$user_id' ORDER BY id DESC"; // Assuming 'id' is the primary key
$result = $conn->query($sql);
// Store the results in an array
$orders = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 1200px;
            margin: 50px auto;
        }

        h3 {
            text-align: center;
            color: #343a40;
            margin-bottom: 30px;
        }

        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .table {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .table thead {
            background-color: #007bff;
            color: white;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .alert-info {
            text-align: center;
            font-size: 1rem;
            color: #0c5460;
            background-color: #d1ecf1;
            border-color: #bee5eb;
        }
    </style>
</head>

<body>
    <?php include 'loader.php'; ?>
    <?php include 'nav.php'; ?>
    <div class="container mt-5">
        <h3 class="mb-4">My Orders</h3>
        <?php if (empty($orders)): ?>
            <div class="alert alert-info" role="alert">
                You have not booked any parcels yet.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Tracking ID</th>
                            <th>Sender Name</th>
                            <th>Receiver Name</th>
                            <th>Parcel Weight (kg)</th>
                            <th>Parcel Type</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($order['track_id']); ?></td>
                                <td><?php echo htmlspecialchars($order['sender_name']); ?></td>
                                <td><?php echo htmlspecialchars($order['receiver_name']); ?></td>
                                <td><?php echo htmlspecialchars($order['parcel_weight']); ?></td>
                                <td><?php echo htmlspecialchars($order['parcel_type']); ?></td>
                                <td>
                                    <?php
                                    $status = $order['status'] ?? 'Pending';
                                    $status_class = match ($status) {
                                        'Pending' => 'text-warning',
                                        'Shipped' => 'text-info',
                                        'Delivered' => 'text-success',
                                        default => 'text-secondary'
                                   };
                                    echo "<span class='$status_class'><i class='fas fa-circle'></i> $status</span>";
                                    ?>
                                </td>
                                <td>
                                    <?php if ($status === 'Pending'): ?>
                                        <!-- Button to cancel the parcel -->
                                        <form action="cancel_parcel.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="parcel_id" value="<?php echo htmlspecialchars($order['id']); ?>">
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to cancel this parcel?');">Cancel Parcel</button>
                                        </form>
                                    <?php elseif ($status === 'Delivered'): ?>
                                        <span class="text-success">Delivered</span>
                                    <?php else: ?>
                                        <!-- You can add other statuses here if needed -->
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    <?php include 'footer.php'; ?>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html> 